--
-- Database: `arma`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_captcha`
--

DROP TABLE IF EXISTS `app_captcha`;
CREATE TABLE `app_captcha` (
  `appcaptcha_id` int(11) NOT NULL,
  `appcomponent_id` int(11) NOT NULL,
  `ipaddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `captchatext` varchar(8) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `app_captcha`
--

INSERT INTO `app_captcha` (`appcaptcha_id`, `appcomponent_id`, `ipaddress`, `captchatext`) VALUES
(2, 225, '149.164.7.157', 'lcff92fc'),
(4, 225, '173.174.150.185', '490df591'),
(5, 225, '184.58.183.158', '071120ne'),
(7, 225, '64.53.243.54', '6f8h6v9d'),
(8, 225, '80.1.114.143', '6a5dccbf'),
(9, 225, '73.114.32.186', '6fdxedb8'),
(18, 225, '184.88.193.240', '6c8yb3hf'),
(19, 225, '50.92.251.109', '96tfcfs5'),
(20, 225, '74.65.187.35', 'an3ivibx'),
(22, 225, '75.121.63.238', 'xbbd434a'),
(23, 225, '98.208.93.57', '8l8sc2zc'),
(24, 225, '23.118.177.39', '2a879nn8');

-- --------------------------------------------------------

--
-- Table structure for table `app_components`
--

DROP TABLE IF EXISTS `app_components`;
CREATE TABLE `app_components` (
  `appcomponent_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `componenttype` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `required` int(11) NOT NULL,
  `tooltip` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `ordernum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `app_components`
--

INSERT INTO `app_components` (`appcomponent_id`, `name`, `componenttype`, `required`, `tooltip`, `ordernum`) VALUES
(225, 'Captcha', 'captcha', 0, '', 11);

-- --------------------------------------------------------

--
-- Table structure for table `app_selectvalues`
--

DROP TABLE IF EXISTS `app_selectvalues`;
CREATE TABLE `app_selectvalues` (
  `appselectvalue_id` int(11) NOT NULL,
  `appcomponent_id` int(11) NOT NULL,
  `componentvalue` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `app_values`
--

DROP TABLE IF EXISTS `app_values`;
CREATE TABLE `app_values` (
  `appvalue_id` int(11) NOT NULL,
  `appcomponent_id` int(11) NOT NULL,
  `memberapp_id` int(11) NOT NULL,
  `appvalue` mediumtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clocks`
--

DROP TABLE IF EXISTS `clocks`;
CREATE TABLE `clocks` (
  `clock_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(7) COLLATE utf8_unicode_ci NOT NULL,
  `timezone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ordernum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `clocks`
--

INSERT INTO `clocks` (`clock_id`, `name`, `color`, `timezone`, `ordernum`) VALUES
(1, 'Eastern Time', '#16A800', 'America/New_York', 4),
(6, 'Central Time', '#C99000', 'America/Chicago', 3),
(7, 'Moutain Time', '#5E00FF', 'America/Denver', 2),
(8, 'Pacific Time', '#006FFF', 'America/Los_Angeles', 1);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL,
  `news_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `dateposted` int(11) NOT NULL,
  `message` mediumtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `console`
--

DROP TABLE IF EXISTS `console`;
CREATE TABLE `console` (
  `console_id` int(11) NOT NULL,
  `consolecategory_id` int(11) NOT NULL,
  `pagetitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `filename` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `sortnum` int(11) NOT NULL,
  `adminoption` int(11) NOT NULL,
  `sep` int(11) NOT NULL,
  `defaultconsole` int(11) NOT NULL,
  `hide` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `console`
--

INSERT INTO `console` (`console_id`, `consolecategory_id`, `pagetitle`, `filename`, `sortnum`, `adminoption`, `sep`, `defaultconsole`, `hide`) VALUES
(1, 1, 'Add New Rank', 'admin/addrank.php', 1, 1, 0, 1, 0),
(2, 1, 'Manage Ranks', 'admin/manageranks.php', 2, 1, 0, 1, 0),
(5, 2, 'Add Member', 'membermanagement/addmember.php', 3, 0, 0, 1, 0),
(6, 2, 'Promote Member', 'membermanagement/promotemember.php', 2, 0, 0, 1, 0),
(7, 2, 'Demote Member', 'membermanagement/demotemember.php', 8, 0, 0, 1, 0),
(8, 2, 'Set Member''s Rank', 'membermanagement/setrank.php', 9, 0, 0, 1, 0),
(9, 10, 'Add New Medal', 'admin/addmedal.php', 2, 1, 0, 1, 0),
(10, 10, 'Manage Medals', 'admin/managemedals.php', 3, 1, 0, 1, 0),
(11, 3, 'Edit Profile', 'editprofile.php', 4, 0, 0, 1, 0),
(12, 1, '-separator-', '', 28, 1, 1, 0, 0),
(14, 1, 'Add Games Played', 'admin/addgamesplayed.php', 6, 1, 0, 1, 0),
(15, 1, 'Manage Games Played', 'admin/managegamesplayed.php', 7, 1, 0, 1, 0),
(17, 1, 'Add Custom Page', 'admin/addcustompages.php', 9, 1, 0, 1, 0),
(18, 1, 'Manage Custom Pages', 'admin/managecustompages.php', 10, 1, 0, 1, 0),
(19, 1, '-separator-', '', 5, 1, 1, 0, 0),
(20, 2, 'Disable a Member', 'membermanagement/disablemember.php', 1, 0, 0, 1, 0),
(21, 2, 'Delete Member', 'membermanagement/deletemember.php', 5, 0, 0, 1, 0),
(22, 1, 'Add New Rank Category', 'admin/addrankcategory.php', 3, 1, 0, 1, 0),
(23, 1, 'Manage Rank Categories', 'admin/managerankcategories.php', 4, 1, 0, 1, 0),
(25, 1, 'Add Console Option', 'admin/addconsoleoption.php', 15, 1, 0, 1, 0),
(31, 1, 'Manage Console Options', 'admin/manageconsole.php', 16, 1, 0, 1, 0),
(32, 1, 'Add New Console Category', 'admin/addconsolecategory.php', 17, 1, 0, 1, 0),
(33, 1, 'Manage Console Categories', 'admin/manageconsolecategories.php', 18, 1, 0, 1, 0),
(51, 1, '-separator-', '', 8, 1, 1, 1, 0),
(52, 1, '-separator-', '', 14, 1, 1, 1, 0),
(54, 14, '-separator-', '', 4, 1, 1, 1, 0),
(55, 14, 'Add Download Category', 'admin/adddownloadcategory.php', 2, 1, 0, 1, 0),
(56, 14, 'Manage Download Categories', 'admin/managedownloadcategories.php', 3, 1, 0, 1, 0),
(60, 1, '-separator-', '', 23, 1, 1, 1, 0),
(61, 1, 'Modify Current Theme', 'admin/edittheme.php', 29, 1, 0, 1, 0),
(62, 1, 'Website Settings', 'admin/sitesettings.php', 30, 1, 0, 1, 0),
(63, 1, 'Add Profile Category', 'admin/addprofilecategory.php', 26, 1, 0, 1, 0),
(64, 1, 'Manage Profile Categories', 'admin/manageprofilecategories.php', 27, 1, 0, 1, 0),
(65, 1, 'Add Profile Option', 'admin/addprofileoption.php', 24, 1, 0, 1, 0),
(66, 1, 'Manage Profile Options', 'admin/manageprofileoptions.php', 25, 1, 0, 1, 0),
(70, 2, '-separator-', '', 7, 0, 1, 0, 0),
(71, 7, 'Create a Squad', 'squads/create.php', 2, 0, 0, 1, 0),
(72, 7, 'View Your Squads', 'squads/index.php', 5, 0, 0, 1, 0),
(73, 7, 'Apply to a Squad', 'squads/apply.php', 3, 0, 0, 1, 0),
(74, 7, 'View Squad Invitations', 'squads/viewinvites.php', 4, 0, 0, 1, 0),
(75, 8, 'Create a Tournament', 'tournaments/create.php', 1, 0, 0, 1, 0),
(76, 8, 'Manage Tournaments', 'tournaments/manage.php', 3, 0, 0, 1, 0),
(77, 8, 'Manage My Matches', 'tournaments/managematches.php', 4, 0, 0, 1, 0),
(78, 17, 'Private Messages', 'privatemessages/index.php', 2, 0, 0, 1, 0),
(80, 3, 'Edit My Game Stats', 'editmygamestats.php', 3, 0, 0, 1, 0),
(82, 9, 'Post News', 'news/postnews.php', 2, 0, 0, 1, 0),
(83, 9, 'Manage News', 'news/managenews.php', 5, 0, 0, 1, 0),
(84, 9, 'View Private News', 'news/privatenews.php', 6, 0, 0, 1, 0),
(85, 9, 'Post Comment', 'news/postcomment.php', 3, 0, 0, 1, 1),
(86, 2, 'Undisable Member', 'membermanagement/undisablemember.php', 4, 0, 0, 1, 0),
(87, 10, 'Award Medal', 'medals/awardmedal.php', 1, 0, 0, 1, 0),
(88, 10, 'Revoke Medal', 'medals/revokemedal.php', 5, 0, 0, 1, 0),
(89, 3, 'Change Password', 'changepassword.php', 5, 0, 0, 1, 0),
(90, 2, '-separator-', '', 11, 0, 1, 0, 0),
(91, 2, 'Reset Member Password', 'membermanagement/resetpassword.php', 16, 0, 0, 1, 0),
(92, 3, 'View Logs', 'logs.php', 7, 0, 0, 1, 0),
(93, 9, 'Post in Shoutbox', 'news/postshoutbox.php', 4, 0, 0, 1, 1),
(96, 2, 'Registration Options', 'membermanagement/registrationoptions.php', 12, 0, 0, 1, 0),
(97, 2, 'Member Application', 'membermanagement/memberapplication.php', 13, 0, 0, 1, 0),
(98, 2, 'View Member Applications', 'membermanagement/viewapplications.php', 14, 0, 0, 1, 0),
(99, 11, 'Diplomacy: Add a Clan', 'diplomacy/addclan.php', 1, 0, 0, 1, 0),
(100, 11, 'Diplomacy: Manage Clans', 'diplomacy/manageclans.php', 2, 0, 0, 1, 0),
(101, 11, 'View Diplomacy Requests', 'diplomacy/viewrequests.php', 3, 0, 0, 1, 0),
(102, 11, 'Manage Diplomacy Statuses', 'diplomacy/diplomacystatuses.php', 6, 0, 0, 1, 0),
(103, 11, '-seperator-', '', 4, 0, 1, 1, 0),
(104, 11, 'Add Diplomacy Status', 'diplomacy/adddiplomacystatus.php', 5, 0, 0, 1, 0),
(105, 12, 'Add Event', 'events/addevent.php', 2, 0, 0, 1, 0),
(106, 12, 'Manage My Events', 'events/manage.php', 3, 0, 0, 1, 0),
(107, 12, 'View Event Invitations', 'events/viewinvites.php', 4, 0, 0, 1, 0),
(108, 1, 'Add Custom Form Page', 'admin/addcustomformpage.php', 11, 1, 0, 1, 0),
(109, 1, 'Manage Custom Form Pages', 'admin/managecustomforms.php', 12, 1, 0, 1, 0),
(110, 1, 'View Custom Form Submissions', 'admin/customformsubmissions.php', 13, 1, 0, 1, 0),
(111, 9, 'Modify News Ticker', 'news/newsticker.php', 8, 0, 0, 1, 0),
(113, 8, 'Join a Tournament', 'tournaments/join.php', 2, 0, 0, 1, 0),
(114, 1, 'Member''s Only Pages', 'admin/membersonlypages.php', 31, 1, 0, 1, 0),
(118, 13, 'Add Forum Category', 'forum/addcategory.php', 5, 0, 0, 1, 0),
(119, 13, 'Manage Forum Categories', 'forum/managecategories.php', 6, 0, 0, 1, 0),
(120, 13, '-seperator-', '', 7, 0, 1, 1, 0),
(121, 13, 'Add Board', 'forum/addboard.php', 8, 0, 0, 1, 0),
(122, 13, 'Manage Boards', 'forum/manageboards.php', 9, 0, 0, 1, 0),
(123, 13, 'Post Topic', 'forum/post.php', 3, 0, 0, 1, 1),
(124, 13, 'Manage Moderators', 'forum/managemoderators.php', 10, 0, 0, 1, 0),
(125, 13, 'Manage Forum Posts', 'forum/manageposts.php', 4, 0, 0, 1, 1),
(126, 3, 'Change Username', 'changeusername.php', 6, 0, 0, 1, 0),
(127, 2, 'Set Member''s Recruiter', 'membermanagement/setrecruiter.php', 17, 0, 0, 1, 0),
(128, 2, 'Set Member''s Recruit Date', 'membermanagement/setrecruitdate.php', 18, 0, 0, 1, 0),
(129, 2, '-seperator-', '', 15, 0, 1, 1, 0),
(134, 1, 'Clear Logs', 'admin/clearlogs.php', 32, 1, 0, 1, 0),
(135, 10, '-separator-', '', 4, 0, 1, 0, 0),
(136, 1, '-seperator-', '', 33, 0, 1, 1, 0),
(137, 1, 'Add Menu Category', 'admin/addmenucategory.php', 34, 0, 0, 1, 0),
(138, 1, 'Add Menu Item', 'admin/addmenuitem.php', 36, 0, 0, 1, 0),
(139, 1, 'Manage Menu Categories', 'admin/managemenucategory.php', 35, 0, 0, 1, 0),
(140, 1, 'Manage Menu Items', 'admin/managemenuitem.php', 37, 0, 0, 1, 0),
(141, 9, 'Manage Home Page Images', 'news/manageimages.php', 11, 0, 0, 1, 0),
(142, 9, 'Add Home Page Image', 'news/addimage.php', 10, 0, 0, 1, 0),
(143, 9, '-seperator-', '', 9, 0, 1, 1, 0),
(144, 13, 'Post Forum Attachments', 'forum/postattachments.php', 2, 0, 0, 1, 1),
(145, 14, 'Add Download', 'downloads/adddownload.php', 1, 0, 0, 1, 0),
(146, 14, 'Manage Downloads', 'downloads/managedownloads.php', 5, 0, 0, 1, 0),
(147, 13, '-seperator-', '', 11, 0, 1, 1, 0),
(148, 13, 'Forum Settings', 'forum/forumsettings.php', 12, 0, 0, 1, 0),
(150, 1, '-seperator-', '', 38, 0, 1, 1, 0),
(165, 1, 'Plugin Manager', 'admin/pluginmanager.php', 39, 0, 0, 1, 0),
(171, 2, 'Set Promotion Power', 'membermanagement/setpromotionpower.php', 10, 0, 0, 1, 0),
(172, 2, '-seperator-', '', 19, 0, 1, 1, 0),
(173, 2, 'Set Member Inactive Status', 'membermanagement/iaoptions.php', 20, 0, 0, 1, 0),
(174, 2, 'View Inactive Requests', 'membermanagement/inactiverequests.php', 21, 0, 0, 1, 0),
(175, 3, 'Inactive Request', 'requestinactive.php', 8, 0, 0, 1, 0),
(176, 3, 'Cancel IA', 'cancelinactive.php', 1, 0, 0, 1, 1),
(187, 17, '-separator-', '', 3, 0, 1, 0, 0),
(188, 17, 'Add PM Folder', 'privatemessages/addfolder.php', 4, 0, 0, 1, 0),
(189, 17, 'Manage PM Folders', 'privatemessages/managefolders.php', 5, 0, 0, 1, 0),
(190, 9, 'HTML in News Posts', '', 1, 0, 0, 1, 1),
(191, 9, 'Manage Shoutbox Posts', 'news/manageshoutbox.php', 7, 0, 0, 1, 0),
(192, 2, 'Change Member Username', 'membermanagement/changememberusername.php', 6, 0, 0, 1, 0),
(193, 1, 'IP Banning', 'admin/ipbanning.php', 40, 0, 0, 1, 0),
(194, 18, 'Create a Poll', 'polls/createpoll.php', 2, 0, 0, 1, 0),
(195, 18, 'Manage Polls', 'polls/managepolls.php', 3, 0, 0, 1, 0),
(196, 18, 'View Poll Results', '', 1, 0, 0, 1, 1),
(200, 13, 'Move Topic', 'forum/movetopic.php', 1, 0, 0, 1, 1),
(201, 7, 'Manage All Squads', '', 1, 1, 0, 1, 1),
(202, 12, 'Manage All Events', '', 1, 1, 0, 1, 1),
(203, 16, 'Add Social Media Icon', 'social/add.php', 1, 0, 0, 1, 0),
(204, 16, 'Manage Social Media Icons', 'social/manage.php', 2, 0, 0, 1, 0),
(209, 20, 'Add World Clock', 'worldclocks/addclock.php', 1, 1, 0, 1, 0),
(210, 20, 'Manage World Clocks', 'worldclocks/manageclocks.php', 2, 0, 0, 1, 0),
(211, 20, 'World Clock Settings', 'worldclocks/settings.php', 3, 0, 0, 1, 0),
(219, 3, 'E-mail Notification Settings', 'emailnotifications.php', 2, 0, 0, 1, 0),
(220, 17, 'E-mail Private Messages', '', 1, 1, 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `consolecategory`
--

DROP TABLE IF EXISTS `consolecategory`;
CREATE TABLE `consolecategory` (
  `consolecategory_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ordernum` int(11) NOT NULL,
  `adminoption` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `consolecategory`
--

INSERT INTO `consolecategory` (`consolecategory_id`, `name`, `ordernum`, `adminoption`) VALUES
(1, 'Administrator Options', 1, 1),
(2, 'Member Management', 5, 0),
(3, 'Account Options', 7, 0),
(7, 'Squads', 3, 0),
(8, 'Tournaments', 2, 0),
(9, 'News', 6, 0),
(10, 'Medals', 4, 0),
(11, 'Diplomacy Options', 8, 0),
(12, 'Events', 9, 0),
(13, 'Forum Management', 10, 0),
(14, 'Downloads', 11, 0),
(16, 'Social Media Connect', 12, 0),
(17, 'Private Messages', 13, 0),
(18, 'Polls', 14, 0),
(19, 'Donations', 15, 0),
(20, 'World Clocks', 16, 0);

-- --------------------------------------------------------

--
-- Table structure for table `console_members`
--

DROP TABLE IF EXISTS `console_members`;
CREATE TABLE `console_members` (
  `privilege_id` int(11) NOT NULL,
  `console_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `allowdeny` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customform`
--

DROP TABLE IF EXISTS `customform`;
CREATE TABLE `customform` (
  `customform_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pageinfo` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `submitmessage` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `submitlink` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `specialform` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customform_components`
--

DROP TABLE IF EXISTS `customform_components`;
CREATE TABLE `customform_components` (
  `component_id` int(11) NOT NULL,
  `customform_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `componenttype` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `required` int(11) NOT NULL,
  `tooltip` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `sortnum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customform_selectvalues`
--

DROP TABLE IF EXISTS `customform_selectvalues`;
CREATE TABLE `customform_selectvalues` (
  `selectvalue_id` int(11) NOT NULL,
  `component_id` int(11) NOT NULL,
  `componentvalue` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `sortnum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customform_submission`
--

DROP TABLE IF EXISTS `customform_submission`;
CREATE TABLE `customform_submission` (
  `submission_id` int(11) NOT NULL,
  `customform_id` int(11) NOT NULL,
  `submitdate` int(11) NOT NULL,
  `ipaddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `seenstatus` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customform_values`
--

DROP TABLE IF EXISTS `customform_values`;
CREATE TABLE `customform_values` (
  `value_id` int(11) NOT NULL,
  `submission_id` int(11) NOT NULL,
  `component_id` int(11) NOT NULL,
  `formvalue` mediumtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `custompages`
--

DROP TABLE IF EXISTS `custompages`;
CREATE TABLE `custompages` (
  `custompage_id` int(11) NOT NULL,
  `pagename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pageinfo` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `custompages`
--

INSERT INTO `custompages` (`custompage_id`, `pagename`, `pageinfo`) VALUES
(11, 'History', '<p style="text-align: center;">This is the clan history.</p>\n<p style="text-align: center;">&nbsp;</p>\n<p style="text-align: center;">This is actually just a custom page...</p>'),
(13, 'Rules', '<p>Rule 1. Don''t be a dumbass.</p>\r\n<p>Rule 2. Hueys are life.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `diplomacy`
--

DROP TABLE IF EXISTS `diplomacy`;
CREATE TABLE `diplomacy` (
  `diplomacy_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `diplomacystatus_id` int(11) NOT NULL,
  `dateadded` int(11) NOT NULL,
  `clanname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `leaders` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `clansize` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `clantag` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `skill` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `gamesplayed` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `extrainfo` mediumtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `diplomacy_request`
--

DROP TABLE IF EXISTS `diplomacy_request`;
CREATE TABLE `diplomacy_request` (
  `diplomacyrequest_id` int(11) NOT NULL,
  `ipaddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateadded` int(11) NOT NULL,
  `diplomacystatus_id` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `clanname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `clantag` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `clansize` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `gamesplayed` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `leaders` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `confirmemail` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `diplomacy_status`
--

DROP TABLE IF EXISTS `diplomacy_status`;
CREATE TABLE `diplomacy_status` (
  `diplomacystatus_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `imageurl` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `imagewidth` int(11) NOT NULL,
  `imageheight` int(11) NOT NULL,
  `ordernum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `diplomacy_status`
--

INSERT INTO `diplomacy_status` (`diplomacystatus_id`, `name`, `imageurl`, `imagewidth`, `imageheight`, `ordernum`) VALUES
(1, 'Ally', 'images/diplomacy/status_50e3b3406ddf8.png', 0, 0, 3),
(2, 'Enemy', 'images/diplomacy/status_50e3b36d60f5a.png', 20, 20, 1),
(3, 'Neutral', 'images/diplomacy/status_50e3b37ebd1fc.png', 0, 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `downloadcategory`
--

DROP TABLE IF EXISTS `downloadcategory`;
CREATE TABLE `downloadcategory` (
  `downloadcategory_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ordernum` int(11) NOT NULL,
  `accesstype` int(11) NOT NULL,
  `specialkey` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `downloadcategory`
--

INSERT INTO `downloadcategory` (`downloadcategory_id`, `name`, `ordernum`, `accesstype`, `specialkey`) VALUES
(5, 'Forum Attachments', 1, 0, 'forumattachments'),
(6, 'Replays', 2, 0, ''),
(7, 'Videos', 3, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `downloads`
--

DROP TABLE IF EXISTS `downloads`;
CREATE TABLE `downloads` (
  `download_id` int(11) NOT NULL,
  `downloadcategory_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `dateuploaded` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mimetype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `filesize` int(11) NOT NULL,
  `splitfile1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `splitfile2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `downloadcount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `downloads`
--

INSERT INTO `downloads` (`download_id`, `downloadcategory_id`, `member_id`, `dateuploaded`, `name`, `filename`, `mimetype`, `filesize`, `splitfile1`, `splitfile2`, `description`, `downloadcount`) VALUES
(15, 5, 13, 1378008075, '', '218d8d91a9620cebcc6e3f695433c0dd.jpg', 'image/jpeg', 16527, 'downloads/files/forumattachment/split_13780080755222bc0bdd010', 'downloads/files/forumattachment/split_13780080755222bc0bdd2ef', '', 0),
(16, 5, 13, 1378008075, '', '1323032613_trophy.png', 'image/png', 15325, 'downloads/files/forumattachment/split_13780080755222bc0bdf090', 'downloads/files/forumattachment/split_13780080755222bc0bdf36d', '', 0),
(17, 5, 13, 1378008153, '', 'phpinfo.php', 'text/x-php', 62, 'downloads/files/forumattachment/split_13780081535222bc59dd1ac', 'downloads/files/forumattachment/split_13780081535222bc59dd4e3', '', 0),
(19, 5, 13, 1378064028, '', 'iframe.html', 'text/html', 533, 'downloads/files/forumattachment/split_13780640275223969bf3c19', 'downloads/files/forumattachment/split_13780640275223969bf3e57', '', 3),
(20, 6, 13, 1378273105, 'Test Download 2', 'SplatterSocialIcons.zip', 'application/zip', 75393, 'downloads/split_13782731055226c7515288f', 'downloads/split_13782731055226c75152b34', 'sdfasdf', 0),
(21, 6, 13, 1378273133, 'Test 2', 'php_filesplit2.zip', 'application/zip', 1588, 'downloads/split_13782731335226c76de5c3d', 'downloads/split_13782731335226c76de971a', 'asdfs', 0),
(22, 6, 13, 1378273157, 'lol', 'CamStudioCodec-1.4-w32.zip', 'application/zip', 34510, 'downloads/split_13782731575226c7854346f', 'downloads/split_13782731575226c785436fc', 'wut', 0),
(23, 7, 13, 1378273371, 'Flow', 'flowplayer-3.2.7.swf', 'application/x-shockwave-flash', 120221, 'downloads/split_13782733715226c85bceb21', 'downloads/split_13782733715226c85bd333e', 'yo', 0),
(24, 7, 13, 1378276276, 'test final', 'flowplayer-3.2.7.swf', 'application/x-shockwave-flash', 120221, 'downloads/files/split_13782762765226d3b47718a', 'downloads/files/split_13782762765226d3b47750d', 'asdfs', 2),
(25, 6, 13, 1394083893, 'test', 'filters-2.0.zip', 'application/zip', 11870, 'downloads/files/split_139408389353180835dd0c7', 'downloads/files/split_139408389353180835dd528', 'asdf', 1),
(26, 5, 0, 1401776295, '', '1287666826226.png', 'image/png', 130930, 'downloads/files/forumattachment/split_1401776295538d68a7df419', 'downloads/files/forumattachment/split_1401776295538d68a7dfbe9', '', 1),
(27, 5, 0, 1401776368, '', '1287666826226.png', 'image/png', 130930, 'downloads/files/forumattachment/split_1401776368538d68f050f4f', 'downloads/files/forumattachment/split_1401776368538d68f051337', '', 0),
(28, 5, 0, 1401776368, '', 'avatar_52de4d9a0c0c2.jpg', 'image/jpeg', 42069, 'downloads/files/forumattachment/split_1401776368538d68f059039', 'downloads/files/forumattachment/split_1401776368538d68f059809', '', 0),
(31, 5, 0, 1412037813, '', 'testfile.zip', 'application/zip', 129, 'downloads/files/forumattachment/split_14120378135429fcb52e8ce', 'downloads/files/forumattachment/split_14120378135429fcb52ecb6', '', 5),
(32, 5, 0, 1412720198, '', 'testfile.txt', 'text/plain', 7, 'downloads/files/forumattachment/split_141272019854346646cb2ff', 'downloads/files/forumattachment/split_141272019854346646cbacf', '', 0),
(33, 6, 13, 1419924685, 'test', 'Torch.png', '', 0, 'downloads/files/54a254cd12a35', 'downloads/files/', 'asdf', 0),
(34, 6, 13, 1419924721, 'dsd', 'Torch.png', '', 0, 'downloads/files/54a254f17b730', 'downloads/files/', 'sd', 0),
(35, 6, 13, 1419924831, 'dsd', 'Torch.png', '', 0, 'downloads/files/54a2555fec585', 'downloads/files/', 'sd', 0),
(36, 6, 13, 1419924850, 'dsd', 'Torch.png', '', 0, 'downloads/files/54a25572f0697', 'downloads/files/', 'sd', 0),
(37, 6, 13, 1419924936, 'dsd', 'Torch.png', '', 0, 'downloads/files/54a255c8750a4', 'downloads/files/', 'sd', 0),
(38, 6, 13, 1419924975, 'dsd', 'Torch.png', '', 0, 'downloads/files/54a255ef2eba5', 'downloads/files/', 'sd', 0),
(39, 6, 13, 1419925039, 'dsd', 'stripe-php-latest.zip', '', 0, 'downloads/files/54a2562f8cd92.zip', 'downloads/files/', 'sd', 2),
(40, 6, 13, 1419928345, 'sdfgsdfgs', 'chromecast-master.zip', '', 0, 'downloads/files/54a26319a7e4d.zip.download', 'downloads/files/', '', 0),
(41, 5, 0, 1419928402, '', 'chromecast-master.zip', '', 0, 'downloads/files/forumattachment/54a26352a8e14zip.download', '', '', 0),
(42, 5, 0, 1419928500, '', 'chromecast-master.zip', '', 0, 'downloads/files/forumattachment/54a263b42a10c.zip.download', '', '', 1),
(43, 5, 0, 1419928700, '', 'chromecast-master.zip', '', 0, 'downloads/files/forumattachment/54a2647c3f6db.zip.download', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `download_extensions`
--

DROP TABLE IF EXISTS `download_extensions`;
CREATE TABLE `download_extensions` (
  `extension_id` int(11) NOT NULL,
  `downloadcategory_id` int(11) NOT NULL,
  `extension` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `download_extensions`
--

INSERT INTO `download_extensions` (`extension_id`, `downloadcategory_id`, `extension`) VALUES
(10, 6, '.zip'),
(11, 6, '.rep'),
(15, 7, '.mov'),
(16, 7, '.wmv'),
(17, 7, '.avi'),
(18, 7, '.swf'),
(24, 5, '');

-- --------------------------------------------------------

--
-- Table structure for table `emailnotifications_queue`
--

DROP TABLE IF EXISTS `emailnotifications_queue`;
CREATE TABLE `emailnotifications_queue` (
  `emailnotificationsqueue_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `senddate` int(11) NOT NULL,
  `sent` int(11) NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `emailnotifications_settings`
--

DROP TABLE IF EXISTS `emailnotifications_settings`;
CREATE TABLE `emailnotifications_settings` (
  `emailnotificationsetting_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `tournament_time` int(11) NOT NULL,
  `tournament_unit` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `event_time` int(11) NOT NULL,
  `event_unit` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `privatemessage` int(11) NOT NULL,
  `email_privatemessage` int(11) NOT NULL,
  `forum_topic` int(11) NOT NULL,
  `forum_post` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eventchat`
--

DROP TABLE IF EXISTS `eventchat`;
CREATE TABLE `eventchat` (
  `eventchat_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `datestarted` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eventchat_messages`
--

DROP TABLE IF EXISTS `eventchat_messages`;
CREATE TABLE `eventchat_messages` (
  `eventchatmessage_id` int(11) NOT NULL,
  `eventchat_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `dateposted` int(11) NOT NULL,
  `message` mediumtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eventchat_roomlist`
--

DROP TABLE IF EXISTS `eventchat_roomlist`;
CREATE TABLE `eventchat_roomlist` (
  `eventchatlist_id` int(11) NOT NULL,
  `eventchat_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `inactive` int(11) NOT NULL,
  `lastseen` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eventmessages`
--

DROP TABLE IF EXISTS `eventmessages`;
CREATE TABLE `eventmessages` (
  `eventmessage_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `dateposted` int(11) NOT NULL,
  `message` mediumtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eventmessage_comment`
--

DROP TABLE IF EXISTS `eventmessage_comment`;
CREATE TABLE `eventmessage_comment` (
  `comment_id` int(11) NOT NULL,
  `eventmessage_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `dateposted` int(11) NOT NULL,
  `comment` mediumtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eventpositions`
--

DROP TABLE IF EXISTS `eventpositions`;
CREATE TABLE `eventpositions` (
  `position_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `sortnum` int(11) NOT NULL,
  `modchat` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `invitemembers` int(11) NOT NULL,
  `manageinvites` int(11) NOT NULL,
  `postmessages` int(11) NOT NULL,
  `managemessages` int(11) NOT NULL,
  `attendenceconfirm` int(11) NOT NULL,
  `editinfo` int(11) NOT NULL,
  `eventpositions` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `event_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `startdate` int(11) NOT NULL,
  `timezone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enddate` int(11) NOT NULL,
  `publicprivate` int(11) NOT NULL,
  `visibility` int(11) NOT NULL,
  `messages` int(11) NOT NULL,
  `invitepermission` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `events_members`
--

DROP TABLE IF EXISTS `events_members`;
CREATE TABLE `events_members` (
  `eventmember_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `invitedbymember_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `attendconfirm_admin` int(11) NOT NULL,
  `attendconfirm_member` int(11) NOT NULL,
  `hide` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `event_reminder`
--

DROP TABLE IF EXISTS `event_reminder`;
CREATE TABLE `event_reminder` (
  `eventreminder_id` int(11) NOT NULL,
  `emailnotificationsqueue_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failban`
--

DROP TABLE IF EXISTS `failban`;
CREATE TABLE `failban` (
  `failban_id` int(11) NOT NULL,
  `pagename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ipaddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `failban`
--

INSERT INTO `failban` (`failban_id`, `pagename`, `ipaddress`) VALUES
(1, 'edittheme', '98.208.93.57'),
(2, 'edittheme', '98.208.93.57'),
(3, 'edittheme', '98.208.93.57');

-- --------------------------------------------------------

--
-- Table structure for table `forgotpass`
--

DROP TABLE IF EXISTS `forgotpass`;
CREATE TABLE `forgotpass` (
  `rqid` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `changekey` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timeofrq` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forum_attachments`
--

DROP TABLE IF EXISTS `forum_attachments`;
CREATE TABLE `forum_attachments` (
  `forumattachment_id` int(11) NOT NULL,
  `forumpost_id` int(11) NOT NULL,
  `download_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forum_board`
--

DROP TABLE IF EXISTS `forum_board`;
CREATE TABLE `forum_board` (
  `forumboard_id` int(11) NOT NULL,
  `forumcategory_id` int(11) NOT NULL,
  `subforum_id` int(11) NOT NULL,
  `lastpost_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `accesstype` int(11) NOT NULL,
  `sortnum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `forum_board`
--

INSERT INTO `forum_board` (`forumboard_id`, `forumcategory_id`, `subforum_id`, `lastpost_id`, `name`, `description`, `accesstype`, `sortnum`) VALUES
(1, 1, 0, 0, 'The Bar', 'Talk about shit here.', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `forum_category`
--

DROP TABLE IF EXISTS `forum_category`;
CREATE TABLE `forum_category` (
  `forumcategory_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ordernum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `forum_category`
--

INSERT INTO `forum_category` (`forumcategory_id`, `name`, `ordernum`) VALUES
(1, 'General', 1);

-- --------------------------------------------------------

--
-- Table structure for table `forum_memberaccess`
--

DROP TABLE IF EXISTS `forum_memberaccess`;
CREATE TABLE `forum_memberaccess` (
  `forummemberaccess_id` int(11) NOT NULL,
  `board_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `accessrule` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forum_moderator`
--

DROP TABLE IF EXISTS `forum_moderator`;
CREATE TABLE `forum_moderator` (
  `forummoderator_id` int(11) NOT NULL,
  `forumboard_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `dateadded` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forum_post`
--

DROP TABLE IF EXISTS `forum_post`;
CREATE TABLE `forum_post` (
  `forumpost_id` int(11) NOT NULL,
  `forumtopic_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `dateposted` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `lastedit_date` int(11) NOT NULL,
  `lastedit_member_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forum_rankaccess`
--

DROP TABLE IF EXISTS `forum_rankaccess`;
CREATE TABLE `forum_rankaccess` (
  `forumrankaccess_id` int(11) NOT NULL,
  `board_id` int(11) NOT NULL,
  `rank_id` int(11) NOT NULL,
  `accesstype` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forum_topic`
--

DROP TABLE IF EXISTS `forum_topic`;
CREATE TABLE `forum_topic` (
  `forumtopic_id` int(11) NOT NULL,
  `forumboard_id` int(11) NOT NULL,
  `forumpost_id` int(11) NOT NULL,
  `lastpost_id` int(11) NOT NULL,
  `views` int(11) NOT NULL,
  `replies` int(11) NOT NULL,
  `lockstatus` int(11) NOT NULL,
  `stickystatus` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forum_topicseen`
--

DROP TABLE IF EXISTS `forum_topicseen`;
CREATE TABLE `forum_topicseen` (
  `forumtopicseen_id` int(11) NOT NULL,
  `forumtopic_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `freezemedals_members`
--

DROP TABLE IF EXISTS `freezemedals_members`;
CREATE TABLE `freezemedals_members` (
  `freezemedal_id` int(11) NOT NULL,
  `medal_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `freezetime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gamesplayed`
--

DROP TABLE IF EXISTS `gamesplayed`;
CREATE TABLE `gamesplayed` (
  `gamesplayed_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `imageurl` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `imagewidth` int(11) NOT NULL,
  `imageheight` int(11) NOT NULL,
  `ordernum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `gamesplayed`
--

INSERT INTO `gamesplayed` (`gamesplayed_id`, `name`, `imageurl`, `imagewidth`, `imageheight`, `ordernum`) VALUES
(2, 'Starcraft 2', 'images/gamesplayed/game_4f9dc59c97b06.png', 48, 48, 5),
(5, 'Starcraft', 'images/gamesplayed/game_4fc70ad0a7ab8.gif', 28, 14, 3),
(7, 'Minecraft', 'images/gamesplayed/game_501f58d5683e4.png', 32, 32, 1),
(8, 'Call of Duty', 'images/gamesplayed/game_508dc503812e7.png', 60, 15, 2),
(9, 'World of Warcraft', 'images/gamesplayed/game_508dc7963ba36.png', 0, 0, 4),
(12, 'Black Ops 2', 'images/gamesplayed/game_522d32661c6b3.png', 40, 40, 6),
(18, 'ARMA 3', 'images/gamesplayed/game_581146815a384.png', 0, 0, 7);

-- --------------------------------------------------------

--
-- Table structure for table `gamesplayed_members`
--

DROP TABLE IF EXISTS `gamesplayed_members`;
CREATE TABLE `gamesplayed_members` (
  `gamemember_id` int(11) NOT NULL,
  `gamesplayed_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `gamesplayed_members`
--

INSERT INTO `gamesplayed_members` (`gamemember_id`, `gamesplayed_id`, `member_id`) VALUES
(218, 12, 65),
(219, 5, 69),
(220, 8, 69),
(221, 7, 69),
(222, 5, 70),
(223, 8, 70),
(224, 7, 70),
(225, 5, 71),
(226, 8, 71),
(227, 7, 71),
(228, 2, 72),
(229, 8, 72),
(230, 7, 72),
(321, 12, 13),
(322, 2, 13),
(323, 9, 13),
(324, 5, 13),
(325, 8, 13),
(326, 7, 13),
(327, 2, 48),
(328, 7, 48),
(329, 9, 75),
(330, 9, 76),
(331, 9, 77),
(332, 9, 78),
(333, 9, 79),
(337, 18, 4),
(339, 18, 8);

-- --------------------------------------------------------

--
-- Table structure for table `gamestats`
--

DROP TABLE IF EXISTS `gamestats`;
CREATE TABLE `gamestats` (
  `gamestats_id` int(11) NOT NULL,
  `gamesplayed_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `stattype` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `calcop` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `firststat_id` int(11) NOT NULL,
  `secondstat_id` int(11) NOT NULL,
  `decimalspots` int(11) NOT NULL,
  `ordernum` int(11) NOT NULL,
  `hidestat` int(11) NOT NULL,
  `textinput` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `gamestats`
--

INSERT INTO `gamestats` (`gamestats_id`, `gamesplayed_id`, `name`, `stattype`, `calcop`, `firststat_id`, `secondstat_id`, `decimalspots`, `ordernum`, `hidestat`, `textinput`) VALUES
(1, 8, 'K/D Ratio', 'calculate', 'div', 2, 3, 2, 0, 0, 0),
(2, 8, 'Kills', 'input', '', 0, 0, 0, 1, 0, 0),
(3, 8, 'Deaths', 'input', '', 0, 0, 0, 2, 0, 0),
(4, 5, 'Wins', 'input', '', 0, 0, 0, 0, 0, 0),
(5, 5, 'Losses', 'input', '', 0, 0, 0, 1, 0, 0),
(6, 2, 'Wins', 'input', '', 0, 0, 0, 0, 0, 0),
(7, 2, 'Losses', 'input', '', 0, 0, 0, 1, 0, 0),
(8, 9, 'Level', 'input', '', 0, 0, 0, 0, 0, 0),
(12, 12, 'K/D Ratio', 'input', '', 0, 0, 2, 0, 0, 0),
(13, 12, 'Kills', 'input', '', 0, 0, 0, 1, 0, 0),
(14, 12, 'Deaths', 'input', '', 0, 0, 0, 2, 0, 0),
(18, 12, 'New Stat', 'input', '', 0, 0, 1, 3, 0, 0),
(21, 7, 'Minecraft Username', 'input', '', 0, 0, 2, 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `gamestats_members`
--

DROP TABLE IF EXISTS `gamestats_members`;
CREATE TABLE `gamestats_members` (
  `gamestatmember_id` int(11) NOT NULL,
  `gamestats_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `statvalue` decimal(65,30) NOT NULL,
  `stattext` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateupdated` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hitcounter`
--

DROP TABLE IF EXISTS `hitcounter`;
CREATE TABLE `hitcounter` (
  `hit_id` int(11) NOT NULL,
  `ipaddress` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `dateposted` int(11) NOT NULL,
  `pagename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `totalhits` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `hitcounter`
--

INSERT INTO `hitcounter` (`hit_id`, `ipaddress`, `dateposted`, `pagename`, `totalhits`) VALUES
(1, '98.208.93.57', 1477689900, 'Ranks - ', 430),
(2, '149.164.7.157', 1477685163, 'Promote Member - ', 23),
(3, '150.70.173.21', 1477656485, 'Members - ', 7),
(4, '209.0.146.171', 1477517211, 'Sign Up - ', 2),
(5, '73.235.44.156', 1477528932, '', 71),
(6, '173.174.150.185', 1477603207, '', 12),
(7, '64.53.243.54', 1477692614, '', 57),
(8, '93.159.230.39', 1477528795, '', 1),
(9, '50.92.251.109', 1477695003, '', 19),
(10, '98.212.148.19', 1477624949, '', 2),
(11, '50.121.48.56', 1477538470, '', 5),
(12, '184.58.183.158', 1477622098, 'Poll - ', 21),
(13, '45.35.63.194', 1477542723, '', 1),
(14, '104.238.248.15', 1477559402, '', 1),
(15, '158.69.229.134', 1477561045, '', 1),
(16, '204.13.201.138', 1477573369, '', 1),
(17, '206.225.80.193', 1477573369, '', 3),
(18, '192.42.116.16', 1477573370, '', 1),
(19, '104.131.157.171', 1477573438, '', 2),
(20, '193.171.202.150', 1477573438, '', 2),
(21, '89.234.157.254', 1477573438, '', 1),
(22, '37.157.193.161', 1477573439, '', 1),
(23, '89.187.142.208', 1477573440, '', 1),
(24, '199.249.223.71', 1477573441, '', 2),
(25, '162.242.156.106', 1477578806, '', 2),
(26, '149.164.111.200', 1477578114, '', 7),
(27, '54.184.37.156', 1477583139, '', 1),
(28, '70.198.78.184', 1477585310, '', 1),
(29, '80.1.114.143', 1477695938, 'Ranks - ', 27),
(30, '67.53.14.246', 1477676473, 'Forum - ', 9),
(31, '209.133.211.147', 1477599227, '', 1),
(32, '66.102.8.223', 1477599228, '', 1),
(33, '73.114.32.186', 1477601972, '', 7),
(34, '184.88.193.240', 1477606070, '', 15),
(35, '50.159.19.105', 1477606086, '', 1),
(36, '91.121.83.118', 1477608441, '', 1),
(37, '198.186.192.44', 1477685893, '', 2),
(38, '167.114.233.118', 1477615307, '', 1),
(39, '139.162.163.183', 1477617779, '', 1),
(40, '104.50.11.195', 1477621462, '', 5),
(41, '184.91.38.211', 1477619793, '', 1),
(42, '74.65.187.35', 1477687814, 'Rules - ', 34),
(43, '110.88.44.187', 1477625570, '', 1),
(44, '122.177.106.45', 1477632982, '', 1),
(45, '66.249.88.19', 1477634967, '', 1),
(46, '66.102.6.140', 1477660029, '', 3),
(47, '95.175.97.229', 1477635733, '', 1),
(48, '173.236.168.104', 1477646974, '', 1),
(49, '45.32.217.244', 1477647616, '', 1),
(50, '160.9.1.54', 1477652873, 'Members - ', 3),
(51, '75.121.63.238', 1477681096, 'Edit Profile - ', 21),
(52, '150.70.173.9', 1477655031, 'Sign Up - ', 1),
(53, '150.70.173.6', 1477655058, '', 1),
(54, '150.70.188.165', 1477655081, 'Members - ', 1),
(55, '150.70.173.43', 1477655167, '', 1),
(56, '150.70.173.8', 1477655204, '', 1),
(57, '108.50.200.30', 1477695415, 'Medals - ', 9),
(58, '183.82.112.166', 1477677197, '', 1),
(59, '182.61.21.10', 1477678060, '', 1),
(60, '159.203.160.162', 1477679962, '', 1),
(61, '23.118.177.39', 1477689656, '', 16),
(62, '150.70.173.11', 1477686777, '', 1),
(63, '66.249.83.88', 1477687842, '', 1),
(64, '64.178.247.39', 1477696195, '', 13),
(65, '150.70.173.12', 1477696278, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `iarequest`
--

DROP TABLE IF EXISTS `iarequest`;
CREATE TABLE `iarequest` (
  `iarequest_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `requestdate` int(11) NOT NULL,
  `reason` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `requeststatus` int(11) NOT NULL,
  `reviewer_id` int(11) NOT NULL,
  `reviewdate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `iarequest_messages`
--

DROP TABLE IF EXISTS `iarequest_messages`;
CREATE TABLE `iarequest_messages` (
  `iamessage_id` int(11) NOT NULL,
  `iarequest_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `messagedate` int(11) NOT NULL,
  `message` mediumtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `imageslider`
--

DROP TABLE IF EXISTS `imageslider`;
CREATE TABLE `imageslider` (
  `imageslider_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `messagetitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `imageurl` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `fillstretch` varchar(7) COLLATE utf8_unicode_ci NOT NULL,
  `ordernum` int(11) NOT NULL,
  `link` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `linktarget` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `membersonly` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ipban`
--

DROP TABLE IF EXISTS `ipban`;
CREATE TABLE `ipban` (
  `ipban_id` int(11) NOT NULL,
  `ipaddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `exptime` int(11) NOT NULL,
  `dateadded` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `logdate` int(11) NOT NULL,
  `ipaddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` mediumtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`log_id`, `member_id`, `logdate`, `ipaddress`, `message`) VALUES
(1, 1, 1477683155, '98.208.93.57', '<span style=''color: #ffffff''><a href=''/profile.php?mID=2'' style=''color: #048500'' title=''.R9''>.R9</a></span> promoted to rank Captain from Recruit.<br><br><b>Reason:</b><br>'),
(2, 1, 1477683197, '98.208.93.57', '<span style=''color: #ffffff''><a href=''/profile.php?mID=5'' style=''color: #048500'' title=''Arend''>Arend</a></span> promoted to rank 1st Lieutenant from Recruit.<br><br><b>Reason:</b><br>');

-- --------------------------------------------------------

--
-- Table structure for table `medals`
--

DROP TABLE IF EXISTS `medals`;
CREATE TABLE `medals` (
  `medal_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `imageurl` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `imagewidth` int(11) NOT NULL,
  `imageheight` int(11) NOT NULL,
  `autodays` int(11) NOT NULL,
  `autorecruits` int(11) NOT NULL,
  `ordernum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `medals`
--

INSERT INTO `medals` (`medal_id`, `name`, `description`, `imageurl`, `imagewidth`, `imageheight`, `autodays`, `autorecruits`, `ordernum`) VALUES
(2, 'Active Member Medal', 'Awarded for being an active clan member.', 'images/medals/medal_50d53660e7533.gif', 105, 30, 0, 0, 1),
(3, 'Forum Hero', 'Awarded for being active on the forums.', 'images/medals/medal_50d536249845b.gif', 105, 30, 0, 0, 3),
(4, 'Epic Medal', 'Awarded for being epic.', 'images/medals/medal_50d5361482940.gif', 105, 30, 0, 0, 4),
(6, 'Veteran Medal', 'Awarded after being in the clan for 90 days.', 'images/medals/medal_50d535a2dc0f8.gif', 105, 30, 90, 0, 7),
(7, 'Old Timer Medal', 'Awarded for being in the clan for 120 days.', 'images/medals/medal_50d535ef43360.gif', 105, 30, 0, 0, 6),
(8, 'Shooting Star Medal', 'Awarded for being in the clan 150 days.', 'images/medals/medal_50d536049e104.gif', 105, 30, 150, 0, 5),
(9, 'Silver Shield Medal', 'Awarded to members who help the clan with Web Design/Graphics, etc...', 'images/medals/medal_50d53640a63e9.gif', 105, 30, 0, 0, 2),
(10, 'Established Member Medal', 'Awarded after being in the clan for 30 days.', 'images/medals/medal_50d535cada75a.gif', 105, 30, 0, 0, 8);

-- --------------------------------------------------------

--
-- Table structure for table `medals_members`
--

DROP TABLE IF EXISTS `medals_members`;
CREATE TABLE `medals_members` (
  `medalmember_id` int(11) NOT NULL,
  `medal_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `dateawarded` int(11) NOT NULL,
  `reason` mediumtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `memberapps`
--

DROP TABLE IF EXISTS `memberapps`;
CREATE TABLE `memberapps` (
  `memberapp_id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `applydate` int(11) NOT NULL,
  `ipaddress` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `memberadded` int(11) NOT NULL,
  `seenstatus` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `memberapps`
--

INSERT INTO `memberapps` (`memberapp_id`, `username`, `password`, `password2`, `email`, `applydate`, `ipaddress`, `memberadded`, `seenstatus`) VALUES
(1, '.R9', '$2a$04$352230e26fcade69b7b44uwUnxooK2106KFzpeuDkoCVoCA/7JqI2', '$2a$04$352230e26fcade69b7b443', 'travis.brumm@gmail.com', 1477506675, '149.164.7.157', 1, 1),
(2, 'Nightrader', '$2a$09$b8edaf6c15ac28cb59e55uLHyDPNx9d7JCFUnAY8HEUiviugzuFNK', '$2a$09$b8edaf6c15ac28cb59e559', 'nick.mayerson@gmail.com', 1477536152, '184.58.183.158', 1, 1),
(3, 'Luke Jefferson', '$2a$06$7006a43b9f721ae759d48u.3lseazwh73mizv6fGnXvayPtWiH/0W', '$2a$06$7006a43b9f721ae759d483', 'lsgenn@gmail.com', 1477538702, '64.53.243.54', 1, 1),
(4, 'Arend', '$2a$05$ced238bc68dfe2edc25e1u2AYMhlXV6FCDU7gybazLH/iztHmI91K', '$2a$05$ced238bc68dfe2edc25e10', 'ntnbrink1@gmail.com', 1477588906, '80.1.114.143', 1, 1),
(5, 'Zachary', '$2a$05$2ccf3e7690a5b598145d4efNN3qinUeb8rgzKByjoOBQTIVA6ng.a', '$2a$05$2ccf3e7690a5b598145d4f', 'zacheppy@gmail.com', 1477602038, '73.114.32.186', 1, 1),
(6, 'Faewix', '$2a$10$5dbabfe1c034976a0b6d2O51YM6xmlJSbG0sJkoycKBmDe8NIC2aa', '$2a$10$5dbabfe1c034976a0b6d2b', 'ianwolf@gmail.com', 1477606348, '184.88.193.240', 1, 1),
(7, 'Castaway', '$2a$09$e30b3641612257bbf669au715607nNJRbFPWTfyGBvcTF7nYNq8zm', '$2a$09$e30b3641612257bbf669a9', 'castaway15pvp@gmail.com', 1477620729, '74.65.187.35', 1, 1),
(8, 'J.Byram', '$2a$09$809e7445b9ad00f4aa154eKzn5ViJ0BFerlzMjhnqbS2BgOUkWK4K', '$2a$09$809e7445b9ad00f4aa154f', 'joshbyram15@yahoo.com', 1477654830, '75.121.63.238', 1, 1),
(9, 'Beachhead', '$2a$04$3b38dacdb6518f3596b33utr3H1.lL7wrROLb5qJBkoD1fISi.68K', '$2a$04$3b38dacdb6518f3596b337', 'beachhead85@gmail.com', 1477682912, '98.208.93.57', 1, 1),
(10, 'Powzer', '$2a$06$5a0a1d49704b2c73cdcc7ueC3Tf8zCsUzMNDypWgocnsf066gbD.e', '$2a$06$5a0a1d49704b2c73cdcc75', 'bower31@yahoo.com', 1477686458, '23.118.177.39', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
CREATE TABLE `members` (
  `member_id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rank_id` int(11) NOT NULL,
  `profilepic` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `avatar` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `maingame_id` int(11) NOT NULL,
  `birthday` int(11) NOT NULL,
  `datejoined` int(11) NOT NULL,
  `lastlogin` int(11) NOT NULL,
  `lastseen` int(11) NOT NULL,
  `lastseenlink` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `loggedin` int(11) NOT NULL,
  `lastpromotion` int(11) NOT NULL,
  `lastdemotion` int(11) NOT NULL,
  `timesloggedin` int(11) NOT NULL,
  `recruiter` int(11) NOT NULL,
  `ipaddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `profileviews` int(11) NOT NULL,
  `defaultconsole` int(11) NOT NULL,
  `disabled` int(11) NOT NULL,
  `disableddate` int(11) NOT NULL,
  `notifications` int(11) NOT NULL,
  `topicsperpage` int(11) NOT NULL,
  `postsperpage` int(11) NOT NULL,
  `freezerank` int(11) NOT NULL,
  `forumsignature` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `promotepower` int(11) NOT NULL,
  `onia` int(11) NOT NULL,
  `inactivedate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`member_id`, `username`, `password`, `password2`, `rank_id`, `profilepic`, `avatar`, `email`, `maingame_id`, `birthday`, `datejoined`, `lastlogin`, `lastseen`, `lastseenlink`, `loggedin`, `lastpromotion`, `lastdemotion`, `timesloggedin`, `recruiter`, `ipaddress`, `profileviews`, `defaultconsole`, `disabled`, `disableddate`, `notifications`, `topicsperpage`, `postsperpage`, `freezerank`, `forumsignature`, `promotepower`, `onia`, `inactivedate`) VALUES
(1, 'admin', '$2a$06$98bf93c92295029184ba5uB.9R0.7nFTSkSDiAR/auv9RlRfzWAPS', '$2a$06$98bf93c92295029184ba50', 1, '', '', '', 0, 0, 1477506238, 1477689658, 1477691640, '<a href=''http://www.9thsfg.com/ranks.php''>Ranks</a>', 0, 0, 0, 6, 0, '98.208.93.57', 2, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0),
(2, '.R9', '$2a$04$352230e26fcade69b7b44uwUnxooK2106KFzpeuDkoCVoCA/7JqI2', '$2a$04$352230e26fcade69b7b443', 60, '', '', 'travis.brumm@gmail.com', 0, 0, 1477506675, 1477685163, 1477685193, '<a href=''http://9thsfg.com/members/console.php?cID=6''>Promote Member</a>', 0, 1477683155, 0, 3, 0, '149.164.111.200', 1, 0, 0, 0, 0, 0, 0, 1477683155, '', 0, 0, 0),
(3, 'Nightrader', '$2a$09$b8edaf6c15ac28cb59e55uLHyDPNx9d7JCFUnAY8HEUiviugzuFNK', '$2a$09$b8edaf6c15ac28cb59e559', 43, '', '', 'nick.mayerson@gmail.com', 0, 0, 1477536153, 1477676473, 1477676473, '<a href=''http://www.9thsfg.com/forum/''>Forum</a>', 0, 0, 0, 1, 0, '184.58.183.158', 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0),
(4, 'Luke Jefferson', '$2a$06$7006a43b9f721ae759d48u.3lseazwh73mizv6fGnXvayPtWiH/0W', '$2a$06$7006a43b9f721ae759d483', 43, 'images/profile/profile_5812912de41f0.jpg', '', 'lsgenn@gmail.com', 18, 932600674, 1477538702, 1477690631, 1477692614, '<a href=''http://www.9thsfg.com/''>Home Page</a>', 0, 0, 0, 1, 0, '64.53.243.54', 0, 17, 0, 0, 0, 10, 10, 0, '', 0, 0, 0),
(5, 'Arend', '$2a$05$ced238bc68dfe2edc25e1u2AYMhlXV6FCDU7gybazLH/iztHmI91K', '$2a$05$ced238bc68dfe2edc25e10', 59, '', '', 'ntnbrink1@gmail.com', 0, 0, 1477588906, 1477695938, 1477695979, '<a href=''http://www.9thsfg.com/ranks.php''>Ranks</a>', 1, 1477683196, 0, 2, 0, '80.1.114.143', 0, 0, 0, 0, 0, 0, 0, 1477683196, '', 0, 0, 0),
(6, 'Zachary', '$2a$05$2ccf3e7690a5b598145d4efNN3qinUeb8rgzKByjoOBQTIVA6ng.a', '$2a$05$2ccf3e7690a5b598145d4f', 43, '', '', 'zacheppy@gmail.com', 0, 0, 1477602039, 1477602063, 1477602092, '<a href=''http://www.9thsfg.com/index.php''>Home Page</a>', 0, 0, 0, 1, 0, '73.114.32.186', 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0),
(7, 'Faewix', '$2a$10$5dbabfe1c034976a0b6d2O51YM6xmlJSbG0sJkoycKBmDe8NIC2aa', '$2a$10$5dbabfe1c034976a0b6d2b', 43, '', '', 'ianwolf@gmail.com', 0, 0, 1477606348, 1477606363, 1477606384, '<a href=''http://www.9thsfg.com/''>Home Page</a>', 0, 0, 0, 1, 0, '184.88.193.240', 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0),
(8, 'Castaway', '$2a$09$e30b3641612257bbf669au715607nNJRbFPWTfyGBvcTF7nYNq8zm', '$2a$09$e30b3641612257bbf669a9', 43, '', 'images/avatar/avatar_5812b42d010c4.jpg', 'castaway15pvp@gmail.com', 18, 72870, 1477620729, 1477685645, 1477687828, '<a href=''http://www.9thsfg.com/custompage.php?pID=12''>Rules</a>', 0, 0, 0, 3, 0, '74.65.187.35', 0, 17, 0, 0, 0, 10, 10, 0, '', 0, 0, 0),
(9, 'J.Byram', '$2a$09$809e7445b9ad00f4aa154eKzn5ViJ0BFerlzMjhnqbS2BgOUkWK4K', '$2a$09$809e7445b9ad00f4aa154f', 43, '', '', 'joshbyram15@yahoo.com', 0, 0, 1477654830, 1477692056, 1477692158, '<a href=''http://www.9thsfg.com/index.php''>Home Page</a>', 0, 0, 0, 4, 0, '64.178.247.39', 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0),
(10, 'Beachhead', '$2a$04$3b38dacdb6518f3596b33utr3H1.lL7wrROLb5qJBkoD1fISi.68K', '$2a$04$3b38dacdb6518f3596b337', 43, '', '', 'beachhead85@gmail.com', 0, 0, 1477682912, 1477683032, 1477683033, '<a href=''http://www.9thsfg.com/index.php''>Home Page</a>', 0, 0, 0, 1, 0, '98.208.93.57', 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0),
(11, 'Powzer', '$2a$06$5a0a1d49704b2c73cdcc7ueC3Tf8zCsUzMNDypWgocnsf066gbD.e', '$2a$06$5a0a1d49704b2c73cdcc75', 43, '', '', 'bower31@yahoo.com', 0, 0, 1477686458, 1477686473, 1477687143, '<a href=''http://www.9thsfg.com/members.php''>Members</a>', 0, 0, 0, 1, 0, '23.118.177.39', 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `membersonlypage`
--

DROP TABLE IF EXISTS `membersonlypage`;
CREATE TABLE `membersonlypage` (
  `page_id` int(11) NOT NULL,
  `pagename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pageurl` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `dateadded` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menuitem_customblock`
--

DROP TABLE IF EXISTS `menuitem_customblock`;
CREATE TABLE `menuitem_customblock` (
  `menucustomblock_id` int(11) NOT NULL,
  `menuitem_id` int(11) NOT NULL,
  `blocktype` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `code` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menuitem_custompage`
--

DROP TABLE IF EXISTS `menuitem_custompage`;
CREATE TABLE `menuitem_custompage` (
  `menucustompage_id` int(11) NOT NULL,
  `menuitem_id` int(11) NOT NULL,
  `custompage_id` int(11) NOT NULL,
  `prefix` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `linktarget` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `textalign` varchar(25) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `menuitem_custompage`
--

INSERT INTO `menuitem_custompage` (`menucustompage_id`, `menuitem_id`, `custompage_id`, `prefix`, `linktarget`, `textalign`) VALUES
(10, 89, 11, '<b>&middot;</b> ', '', 'left');

-- --------------------------------------------------------

--
-- Table structure for table `menuitem_image`
--

DROP TABLE IF EXISTS `menuitem_image`;
CREATE TABLE `menuitem_image` (
  `menuimage_id` int(11) NOT NULL,
  `menuitem_id` int(11) NOT NULL,
  `imageurl` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `link` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `linktarget` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `imagealign` varchar(25) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menuitem_link`
--

DROP TABLE IF EXISTS `menuitem_link`;
CREATE TABLE `menuitem_link` (
  `menulink_id` int(11) NOT NULL,
  `menuitem_id` int(11) NOT NULL,
  `link` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `linktarget` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `prefix` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `textalign` varchar(25) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `menuitem_link`
--

INSERT INTO `menuitem_link` (`menulink_id`, `menuitem_id`, `link`, `linktarget`, `prefix`, `textalign`) VALUES
(30, 54, 'ranks.php', '', '<b>&middot;</b> ', 'left'),
(31, 55, 'medals.php', '', '<b>&middot;</b> ', 'left'),
(32, 56, 'diplomacy', '', '<b>&middot;</b> ', 'left'),
(33, 57, 'diplomacy/request.php', '', '<b>&middot;</b> ', 'left'),
(34, 67, 'index.php', '', '<b>&middot;</b> ', 'left'),
(36, 75, 'news', '', '<b>&middot;</b> ', 'left'),
(37, 76, 'members.php', '', '<b>&middot;</b> ', 'left'),
(38, 77, 'squads', '', '<b>&middot;</b> ', 'left'),
(39, 78, 'tournaments', '', '<b>&middot;</b> ', 'left'),
(40, 79, 'events', '', '<b>&middot;</b> ', 'left'),
(41, 80, 'forum', '', '<b>&middot;</b> ', 'left'),
(42, 82, 'news', '', '', 'left'),
(43, 83, 'members.php', '', '', 'left'),
(46, 86, 'events', '', '', 'left'),
(47, 87, 'forum', '', '', 'left'),
(48, 91, 'ranks.php', '', '', 'left'),
(49, 92, 'medals.php', '', '', 'left'),
(50, 96, 'custompage.php?pID=13', '', '', 'left');

-- --------------------------------------------------------

--
-- Table structure for table `menuitem_shoutbox`
--

DROP TABLE IF EXISTS `menuitem_shoutbox`;
CREATE TABLE `menuitem_shoutbox` (
  `menushoutbox_id` int(11) NOT NULL,
  `menuitem_id` int(11) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `percentwidth` int(1) NOT NULL,
  `percentheight` int(1) NOT NULL,
  `textboxwidth` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `menuitem_shoutbox`
--

INSERT INTO `menuitem_shoutbox` (`menushoutbox_id`, `menuitem_id`, `width`, `height`, `percentwidth`, `percentheight`, `textboxwidth`) VALUES
(1, 2, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `menu_category`
--

DROP TABLE IF EXISTS `menu_category`;
CREATE TABLE `menu_category` (
  `menucategory_id` int(11) NOT NULL,
  `section` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortnum` int(11) NOT NULL,
  `headertype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `headercode` longtext COLLATE utf8_unicode_ci NOT NULL,
  `accesstype` int(11) NOT NULL,
  `hide` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `menu_category`
--

INSERT INTO `menu_category` (`menucategory_id`, `section`, `name`, `sortnum`, `headertype`, `headercode`, `accesstype`, `hide`) VALUES
(1, 1, 'Shoutbox', 3, 'customcode', 'SHOUTBOX', 0, 0),
(4, 1, 'New Members', 4, 'customcode', 'NEW MEMBERS', 0, 0),
(5, 0, 'Forum Activity', 4, 'customcode', 'FORUM ACTIVITY', 0, 0),
(16, 0, 'Poll', 3, 'customcode', 'POLL', 0, 1),
(17, 0, 'Main Menu', 1, 'customcode', 'MAIN MENU', 0, 0),
(24, 1, 'Log In', 1, 'customcode', 'LOG IN', 2, 0),
(25, 1, 'Logged In', 2, 'customcode', 'LOGGED IN', 1, 0),
(28, 2, 'Top Menu', 1, 'customcode', '', 0, 0),
(29, 0, 'Top Players', 2, 'customcode', 'TOP PLAYERS', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `menu_item`
--

DROP TABLE IF EXISTS `menu_item`;
CREATE TABLE `menu_item` (
  `menuitem_id` int(11) NOT NULL,
  `menucategory_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `itemtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `itemtype_id` int(11) NOT NULL,
  `accesstype` int(1) NOT NULL,
  `hide` int(1) NOT NULL,
  `sortnum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `menu_item`
--

INSERT INTO `menu_item` (`menuitem_id`, `menucategory_id`, `name`, `itemtype`, `itemtype_id`, `accesstype`, `hide`, `sortnum`) VALUES
(2, 1, 'Shoutbox', 'shoutbox', 1, 0, 0, 1),
(4, 4, 'Newest Members', 'newestmembers', 0, 0, 0, 1),
(5, 5, 'Forum Activity', 'forumactivity', 0, 0, 0, 1),
(54, 17, 'Ranks', 'link', 30, 0, 0, 4),
(55, 17, 'Medals', 'link', 31, 0, 0, 8),
(56, 17, 'Diplomacy', 'link', 32, 0, 0, 9),
(57, 17, 'Diplomacy Request', 'link', 33, 0, 0, 10),
(67, 17, 'Home', 'link', 34, 0, 0, 1),
(68, 16, 'Poll', 'poll', 1, 0, 0, 1),
(69, 24, 'Log In', 'login', 0, 0, 0, 1),
(70, 25, 'Logged In', 'login', 0, 0, 0, 1),
(75, 17, 'News', 'link', 36, 0, 0, 2),
(76, 17, 'Members', 'link', 37, 0, 0, 3),
(77, 17, 'Squads', 'link', 38, 0, 0, 5),
(78, 17, 'Tournaments', 'link', 39, 0, 0, 6),
(79, 17, 'Events', 'link', 40, 0, 0, 7),
(80, 17, 'Forum', 'link', 41, 0, 0, 13),
(81, 29, 'Top Player Links', 'top-players', 0, 0, 0, 1),
(82, 28, 'News', 'link', 42, 0, 0, 4),
(83, 28, 'Members', 'link', 43, 0, 0, 5),
(86, 28, 'Events', 'link', 46, 0, 0, 6),
(87, 28, 'Forum', 'link', 47, 0, 0, 7),
(89, 17, 'History', 'custompage', 10, 0, 0, 11),
(91, 28, 'Ranks', 'link', 48, 0, 0, 3),
(92, 28, 'Medals', 'link', 49, 0, 0, 2),
(96, 28, 'Rules', 'link', 50, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `news_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `newstype` int(11) NOT NULL,
  `dateposted` int(11) NOT NULL,
  `postsubject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `newspost` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `lasteditmember_id` int(11) NOT NULL,
  `lasteditdate` int(11) NOT NULL,
  `hpsticky` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`news_id`, `member_id`, `newstype`, `dateposted`, `postsubject`, `newspost`, `lasteditmember_id`, `lasteditdate`, `hpsticky`) VALUES
(1, 1, 3, 1477527324, 'Shoutbox Post', 'Test', 0, 0, 0),
(2, 5, 3, 1477588939, 'Shoutbox Post', 'Test 2', 0, 0, 0),
(3, 5, 3, 1477588950, 'Shoutbox Post', 'Cool, works. Hi guys!', 0, 0, 0),
(4, 2, 3, 1477589500, 'Shoutbox Post', 'WTB ability to edit the site and get it operational.', 0, 0, 0),
(5, 2, 3, 1477589523, 'Shoutbox Post', 'WTS my continually bugging Beach.', 0, 0, 0),
(6, 5, 3, 1477590645, 'Shoutbox Post', 'Goddamnit... stop using accronyms I don''t understand!', 0, 0, 0),
(7, 3, 3, 1477596385, 'Shoutbox Post', 'YOOOOOOOOOO', 0, 0, 0),
(8, 5, 3, 1477596468, 'Shoutbox Post', 'I''m hoping I can clear this data before we finish the site xD', 0, 0, 0),
(9, 4, 3, 1477601374, 'Shoutbox Post', 'Howdy :D', 0, 0, 0),
(10, 2, 3, 1477660130, 'Shoutbox Post', 'Arend - WTB = Willing to Buy : WTS = Willing to Sell', 0, 0, 0),
(11, 2, 3, 1477663889, 'Shoutbox Post', 'https://discord.gg/py6rShb', 0, 0, 0),
(12, 5, 3, 1477685034, 'Shoutbox Post', 'Ah right', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `datesent` int(11) NOT NULL,
  `message` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `icontype` varchar(15) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `member_id`, `datesent`, `message`, `status`, `icontype`) VALUES
(1, 1, 1477506675, 'A new member has signed up!  Go to the <a href=''/members/console.php?cID=98''>View Member Applications</a> page to review the application.', 1, 'general'),
(2, 1, 1477536152, 'A new member has signed up!  Go to the <a href=''/members/console.php?cID=98''>View Member Applications</a> page to review the application.', 1, 'general'),
(3, 1, 1477538702, 'A new member has signed up!  Go to the <a href=''/members/console.php?cID=98''>View Member Applications</a> page to review the application.', 1, 'general'),
(4, 1, 1477588906, 'A new member has signed up!  Go to the <a href=''/members/console.php?cID=98''>View Member Applications</a> page to review the application.', 1, 'general'),
(5, 1, 1477602038, 'A new member has signed up!  Go to the <a href=''/members/console.php?cID=98''>View Member Applications</a> page to review the application.', 1, 'general'),
(6, 1, 1477606348, 'A new member has signed up!  Go to the <a href=''/members/console.php?cID=98''>View Member Applications</a> page to review the application.', 1, 'general'),
(7, 1, 1477620729, 'A new member has signed up!  Go to the <a href=''/members/console.php?cID=98''>View Member Applications</a> page to review the application.', 1, 'general'),
(8, 1, 1477654830, 'A new member has signed up!  Go to the <a href=''/members/console.php?cID=98''>View Member Applications</a> page to review the application.', 1, 'general'),
(9, 1, 1477682912, 'A new member has signed up!  Go to the <a href=''/members/console.php?cID=98''>View Member Applications</a> page to review the application.', 1, 'general'),
(10, 2, 1477683155, 'Your rank has been set to Captain!', 1, 'general'),
(11, 5, 1477683197, 'Your rank has been set to 1st Lieutenant!', 1, 'general'),
(12, 1, 1477686458, 'A new member has signed up!  Go to the <a href=''/members/console.php?cID=98''>View Member Applications</a> page to review the application.', 1, 'general');

-- --------------------------------------------------------

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
CREATE TABLE `plugins` (
  `plugin_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `filepath` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `apikey` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `dateinstalled` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `plugin_config`
--

DROP TABLE IF EXISTS `plugin_config`;
CREATE TABLE `plugin_config` (
  `pluginconfig_id` int(11) NOT NULL,
  `plugin_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `plugin_pages`
--

DROP TABLE IF EXISTS `plugin_pages`;
CREATE TABLE `plugin_pages` (
  `pluginpage_id` int(11) NOT NULL,
  `plugin_id` int(11) NOT NULL,
  `page` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pagepath` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `sortnum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `polls`
--

DROP TABLE IF EXISTS `polls`;
CREATE TABLE `polls` (
  `poll_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `question` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `accesstype` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `multivote` int(11) NOT NULL,
  `displayvoters` int(11) NOT NULL,
  `resultvisibility` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `maxvotes` int(11) NOT NULL,
  `pollend` int(11) NOT NULL,
  `dateposted` int(11) NOT NULL,
  `lastedit_date` int(11) NOT NULL,
  `lastedit_memberid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `polls`
--

INSERT INTO `polls` (`poll_id`, `member_id`, `question`, `accesstype`, `multivote`, `displayvoters`, `resultvisibility`, `maxvotes`, `pollend`, `dateposted`, `lastedit_date`, `lastedit_memberid`) VALUES
(1, 13, 'Whats your favorite color?', 'public', 0, 0, 'open', 0, 0, 1395344025, 1395859418, 13);

-- --------------------------------------------------------

--
-- Table structure for table `poll_memberaccess`
--

DROP TABLE IF EXISTS `poll_memberaccess`;
CREATE TABLE `poll_memberaccess` (
  `pollmemberaccess_id` int(11) NOT NULL,
  `poll_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `accesstype` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `poll_options`
--

DROP TABLE IF EXISTS `poll_options`;
CREATE TABLE `poll_options` (
  `polloption_id` int(11) NOT NULL,
  `poll_id` int(11) NOT NULL,
  `optionvalue` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(7) COLLATE utf8_unicode_ci NOT NULL,
  `sortnum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `poll_options`
--

INSERT INTO `poll_options` (`polloption_id`, `poll_id`, `optionvalue`, `color`, `sortnum`) VALUES
(1, 1, 'Green', '#1AFF00', 0),
(2, 1, 'White', '#FFFFFF', 1),
(3, 1, 'Black', '#000000', 2),
(4, 1, 'Red', '#FF0000', 3),
(5, 1, 'Blue', '#0900FF', 4);

-- --------------------------------------------------------

--
-- Table structure for table `poll_rankaccess`
--

DROP TABLE IF EXISTS `poll_rankaccess`;
CREATE TABLE `poll_rankaccess` (
  `pollrankaccess_id` int(11) NOT NULL,
  `poll_id` int(11) NOT NULL,
  `rank_id` int(11) NOT NULL,
  `accesstype` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `poll_votes`
--

DROP TABLE IF EXISTS `poll_votes`;
CREATE TABLE `poll_votes` (
  `pollvote_id` int(11) NOT NULL,
  `poll_id` int(11) NOT NULL,
  `polloption_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `ipaddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `datevoted` int(11) NOT NULL,
  `votecount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `poll_votes`
--

INSERT INTO `poll_votes` (`pollvote_id`, `poll_id`, `polloption_id`, `member_id`, `ipaddress`, `datevoted`, `votecount`) VALUES
(1, 1, 4, 0, '184.58.183.158', 1477536119, 1),
(2, 1, 1, 0, '184.88.193.240', 1477606289, 1),
(3, 1, 3, 0, '104.50.11.195', 1477618591, 1),
(4, 1, 4, 3, '184.58.183.158', 1477622149, 1),
(5, 1, 3, 0, '74.65.187.35', 1477632099, 1),
(6, 1, 4, 0, '108.50.200.30', 1477677094, 1),
(7, 1, 5, 0, '75.121.63.238', 1477681741, 1),
(8, 1, 3, 11, '23.118.177.39', 1477686988, 18),
(9, 1, 2, 11, '23.118.177.39', 1477687097, 25),
(10, 1, 5, 4, '64.53.243.54', 1477690938, 1);

-- --------------------------------------------------------

--
-- Table structure for table `privatemessages`
--

DROP TABLE IF EXISTS `privatemessages`;
CREATE TABLE `privatemessages` (
  `pm_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `datesent` int(11) NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `originalpm_id` int(11) NOT NULL,
  `deletesender` int(11) NOT NULL,
  `deletereceiver` int(11) NOT NULL,
  `senderfolder_id` int(11) NOT NULL DEFAULT '-1',
  `receiverfolder_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `privatemessage_folders`
--

DROP TABLE IF EXISTS `privatemessage_folders`;
CREATE TABLE `privatemessage_folders` (
  `pmfolder_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ordernum` int(11) NOT NULL,
  `sortnum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `privatemessage_members`
--

DROP TABLE IF EXISTS `privatemessage_members`;
CREATE TABLE `privatemessage_members` (
  `pmmember_id` int(11) NOT NULL,
  `pm_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `grouptype` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `group_id` int(11) NOT NULL,
  `seenstatus` int(11) NOT NULL,
  `deletestatus` int(11) NOT NULL,
  `pmfolder_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profilecategory`
--

DROP TABLE IF EXISTS `profilecategory`;
CREATE TABLE `profilecategory` (
  `profilecategory_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ordernum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `profilecategory`
--

INSERT INTO `profilecategory` (`profilecategory_id`, `name`, `ordernum`) VALUES
(1, 'Personal Information', 1);

-- --------------------------------------------------------

--
-- Table structure for table `profileoptions`
--

DROP TABLE IF EXISTS `profileoptions`;
CREATE TABLE `profileoptions` (
  `profileoption_id` int(11) NOT NULL,
  `profilecategory_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `optiontype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortnum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `profileoptions`
--

INSERT INTO `profileoptions` (`profileoption_id`, `profilecategory_id`, `name`, `optiontype`, `sortnum`) VALUES
(2, 1, 'First Name', 'input', 2),
(3, 1, 'Gender', 'select', 1),
(6, 1, 'Last Name', 'input', 3);

-- --------------------------------------------------------

--
-- Table structure for table `profileoptions_select`
--

DROP TABLE IF EXISTS `profileoptions_select`;
CREATE TABLE `profileoptions_select` (
  `selectopt_id` int(11) NOT NULL,
  `profileoption_id` int(11) NOT NULL,
  `selectvalue` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortnum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `profileoptions_select`
--

INSERT INTO `profileoptions_select` (`selectopt_id`, `profileoption_id`, `selectvalue`, `sortnum`) VALUES
(13, 3, 'Alien', 1),
(14, 3, 'Male', 2),
(15, 3, 'Female', 3);

-- --------------------------------------------------------

--
-- Table structure for table `profileoptions_values`
--

DROP TABLE IF EXISTS `profileoptions_values`;
CREATE TABLE `profileoptions_values` (
  `values_id` int(11) NOT NULL,
  `profileoption_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `inputvalue` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `profileoptions_values`
--

INSERT INTO `profileoptions_values` (`values_id`, `profileoption_id`, `member_id`, `inputvalue`) VALUES
(10, 3, 4, '14'),
(11, 2, 4, 'Not Set'),
(12, 6, 4, 'Not Set'),
(16, 3, 8, '14'),
(17, 2, 8, 'Not Set'),
(18, 6, 8, 'Not Set');

-- --------------------------------------------------------

--
-- Table structure for table `rankcategory`
--

DROP TABLE IF EXISTS `rankcategory`;
CREATE TABLE `rankcategory` (
  `rankcategory_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `imageurl` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `ordernum` int(11) NOT NULL,
  `hidecat` int(11) NOT NULL,
  `useimage` int(1) NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `imagewidth` int(11) NOT NULL,
  `imageheight` int(11) NOT NULL,
  `color` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `rankcategory`
--

INSERT INTO `rankcategory` (`rankcategory_id`, `name`, `imageurl`, `ordernum`, `hidecat`, `useimage`, `description`, `imagewidth`, `imageheight`, `color`) VALUES
(6, 'Officers', '', 3, 0, 0, '', 0, 0, '#048500'),
(7, 'Warrant Officers', '', 2, 0, 0, '', 0, 0, '#67A300'),
(8, 'Enlisted', '', 1, 0, 0, '', 0, 0, '#4A2000');

-- --------------------------------------------------------

--
-- Table structure for table `ranks`
--

DROP TABLE IF EXISTS `ranks`;
CREATE TABLE `ranks` (
  `rank_id` int(11) NOT NULL,
  `rankcategory_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `imageurl` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `imagewidth` int(11) NOT NULL,
  `imageheight` int(11) NOT NULL,
  `ordernum` int(11) NOT NULL,
  `autodays` int(11) NOT NULL,
  `hiderank` int(11) NOT NULL,
  `promotepower` int(11) NOT NULL,
  `autodisable` int(11) NOT NULL,
  `color` varchar(25) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ranks`
--

INSERT INTO `ranks` (`rank_id`, `rankcategory_id`, `name`, `description`, `imageurl`, `imagewidth`, `imageheight`, `ordernum`, `autodays`, `hiderank`, `promotepower`, `autodisable`, `color`) VALUES
(1, 3, 'Administrator', '', '', 0, 0, 1, 0, 1, 0, 0, '#7FFF00'),
(43, 8, 'Recruit', 'Starting Rank', 'images/ranks/rank_4fa58088a6a9d.png', 50, 75, 2, 0, 0, 0, 0, '#00EAFF'),
(44, 8, 'Private', '3 days in clan.', 'images/ranks/rank_5813acce2c6be.png', 100, 100, 3, 3, 0, 0, 0, '#ffffff'),
(45, 8, 'Private First Class', '7 days in clan.', 'images/ranks/rank_5813ae3705141.png', 100, 100, 4, 7, 0, 0, 0, '#ffffff'),
(46, 8, 'Corporal', '', 'images/ranks/rank_5813adc75873f.png', 100, 100, 5, 14, 0, 0, 0, '#ffffff'),
(47, 8, 'Sergeant', '21 days in the clan.', 'images/ranks/rank_5813ad955b684.png', 100, 100, 7, 21, 0, 0, 0, '#ffffff'),
(48, 8, 'Staff Sergeant', '', 'images/ranks/rank_5813ae6e9cdb1.png', 100, 100, 8, 28, 0, 0, 0, '#ffffff'),
(49, 8, 'Sergeant 1st Class (E-7 SFC)', '35 days in the clan.', 'images/ranks/rank_5813aeb70c02b.png', 100, 100, 9, 35, 0, 0, 0, '#ffffff'),
(50, 8, 'Master Sergeant', '', 'images/ranks/rank_5813c700d2bf8.png', 100, 100, 10, 42, 0, 0, 0, '#ffffff'),
(51, 8, '1st Sergeant', '', 'images/ranks/rank_5813c6f08092b.png', 100, 100, 11, 49, 0, 0, 0, '#ffffff'),
(52, 8, 'Sergeant Major', '', 'images/ranks/rank_5813c6af98e6f.png', 100, 100, 12, 56, 0, 0, 0, '#ffffff'),
(53, 7, 'Warrant Officer 1', '', 'images/ranks/rank_5813c5dcd14c3.png', 100, 100, 13, 0, 0, 0, 0, '#ffffff'),
(54, 7, 'Chief Warrant Officer 2', 'Promoted by 2nd Lieutanent or Higher.', 'images/ranks/rank_5813c5f568373.png', 100, 100, 14, 0, 0, 0, 0, '#ffffff'),
(55, 7, 'Chief Warrant Officer 3', '', 'images/ranks/rank_5813c653e41ba.png', 100, 100, 15, 0, 0, 0, 0, '#ffffff'),
(56, 7, 'Chief Warrant Officer 4', '', 'images/ranks/rank_5813c6719defe.png', 100, 100, 16, 0, 0, 52, 0, '#ffffff'),
(57, 7, 'Chief Warrant Officer 5', '', 'images/ranks/rank_5813c689db600.png', 100, 100, 17, 0, 0, 52, 0, '#ffffff'),
(58, 6, '2nd Lieutenant (2LT)', '', 'images/ranks/rank_5813c452d6fe7.png', 100, 100, 18, 0, 0, 55, 0, '#ffffff'),
(59, 6, '1st Lieutenant (1LT)', '', 'images/ranks/rank_5813c4430303e.png', 100, 100, 19, 0, 0, 57, 0, '#ffffff'),
(60, 6, 'Captain (CPT)', '', 'images/ranks/rank_5813c3eb9b674.png', 100, 94, 20, 0, 0, 59, 0, '#ffffff'),
(61, 6, 'Major (MAJ)', '', 'images/ranks/rank_5813c37ed8724.png', 100, 100, 21, 0, 0, 60, 0, '#FF6F00'),
(67, 8, 'Specialist', '', 'images/ranks/rank_58139e84c17ba.png', 100, 100, 6, 0, 0, 0, 0, '#ffffff');

-- --------------------------------------------------------

--
-- Table structure for table `rank_privileges`
--

DROP TABLE IF EXISTS `rank_privileges`;
CREATE TABLE `rank_privileges` (
  `privilege_id` int(11) NOT NULL,
  `rank_id` int(11) NOT NULL,
  `console_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `rank_privileges`
--

INSERT INTO `rank_privileges` (`privilege_id`, `rank_id`, `console_id`) VALUES
(2, 1, 2),
(3, 1, 3),
(6, 1, 7),
(10, 1, 11),
(11, 1, 12),
(12, 1, 14),
(13, 1, 15),
(14, 1, 17),
(15, 1, 18),
(16, 1, 19),
(61, 1, 22),
(62, 1, 23),
(165, 1, 25),
(337, 1, 31),
(338, 1, 32),
(339, 1, 33),
(340, 1, 34),
(367, 1, 21),
(451, 1, 8),
(482, 1, 51),
(483, 1, 52),
(491, 1, 60),
(492, 1, 61),
(493, 1, 62),
(494, 1, 63),
(495, 1, 64),
(496, 1, 65),
(497, 1, 66),
(509, 1, 70),
(517, 1, 71),
(518, 1, 72),
(519, 1, 73),
(520, 1, 74),
(564, 1, 75),
(565, 1, 76),
(573, 1, 83),
(574, 1, 84),
(575, 1, 85),
(578, 1, 86),
(580, 1, 88),
(581, 1, 89),
(582, 1, 90),
(583, 1, 91),
(584, 1, 92),
(585, 1, 93),
(1076, 1, 80),
(1138, 1, 99),
(1139, 1, 100),
(1140, 1, 101),
(1141, 1, 102),
(1143, 1, 104),
(1319, 1, 106),
(1349, 1, 107),
(1515, 43, 85),
(1516, 43, 93),
(1517, 43, 80),
(1518, 43, 106),
(1519, 43, 11),
(1520, 43, 73),
(1522, 43, 74),
(1524, 43, 107),
(1525, 43, 72),
(1526, 43, 89),
(1527, 43, 92),
(1603, 1, 103),
(1626, 43, 82),
(1649, 1, 82),
(1655, 43, 105),
(1679, 1, 105),
(1686, 43, 123),
(1711, 1, 123),
(1715, 1, 1),
(1824, 1, 125),
(1831, 1, 9),
(1838, 1, 10),
(1967, 1, 5),
(2063, 1, 55),
(2065, 1, 56),
(2067, 1, 54),
(2248, 43, 175),
(2272, 1, 175),
(2277, 43, 176),
(2301, 1, 176),
(2306, 43, 113),
(2329, 1, 113),
(2351, 1, 20),
(2354, 1, 171),
(2369, 1, 6),
(2376, 1, 87),
(2381, 43, 78),
(2404, 1, 78),
(2410, 43, 187),
(2433, 1, 187),
(2524, 1, 190),
(2526, 1, 192),
(2531, 43, 188),
(2554, 1, 188),
(2559, 43, 189),
(2582, 1, 189),
(2589, 1, 98),
(2687, 43, 219),
(2710, 1, 219),
(2712, 1, 209),
(2714, 1, 210),
(2716, 1, 211),
(2718, 1, 196),
(2720, 1, 194),
(2722, 1, 195),
(2724, 1, 220),
(2726, 1, 203),
(2728, 1, 204),
(2730, 1, 145),
(2732, 1, 146),
(2734, 1, 200),
(2736, 1, 118),
(2738, 1, 119),
(2740, 1, 121),
(2742, 1, 122),
(2744, 1, 124),
(2746, 1, 147),
(2748, 1, 120),
(2750, 1, 148),
(2752, 1, 202),
(2754, 1, 126),
(2756, 1, 191),
(2758, 1, 111),
(2760, 1, 96),
(2762, 1, 97),
(2764, 1, 129),
(2766, 1, 127),
(2768, 1, 128),
(2770, 1, 172),
(2772, 1, 173),
(2774, 1, 174),
(2776, 1, 135),
(2778, 1, 201),
(2952, 44, 176),
(2953, 44, 78),
(2954, 44, 82),
(2955, 44, 105),
(2956, 44, 113),
(2957, 44, 219),
(2958, 44, 73),
(2959, 44, 80),
(2960, 44, 85),
(2961, 44, 106),
(2962, 44, 123),
(2963, 44, 187),
(2964, 44, 11),
(2965, 44, 74),
(2966, 44, 93),
(2967, 44, 107),
(2968, 44, 188),
(2969, 44, 72),
(2970, 44, 89),
(2971, 44, 189),
(2972, 44, 92),
(2973, 44, 175),
(2974, 47, 176),
(2975, 47, 78),
(2976, 47, 82),
(2977, 47, 105),
(2978, 47, 113),
(2979, 47, 219),
(2980, 47, 73),
(2981, 47, 80),
(2982, 47, 85),
(2983, 47, 106),
(2984, 47, 123),
(2985, 47, 187),
(2986, 47, 11),
(2987, 47, 74),
(2988, 47, 93),
(2989, 47, 107),
(2990, 47, 188),
(2991, 47, 72),
(2992, 47, 89),
(2993, 47, 189),
(2994, 47, 92),
(2995, 47, 175),
(2996, 46, 176),
(2997, 46, 78),
(2998, 46, 82),
(2999, 46, 105),
(3000, 46, 113),
(3001, 46, 219),
(3002, 46, 73),
(3003, 46, 80),
(3004, 46, 85),
(3005, 46, 106),
(3006, 46, 123),
(3007, 46, 187),
(3008, 46, 11),
(3009, 46, 74),
(3010, 46, 93),
(3011, 46, 107),
(3012, 46, 188),
(3013, 46, 72),
(3014, 46, 89),
(3015, 46, 189),
(3016, 46, 92),
(3017, 46, 175),
(3018, 45, 176),
(3019, 45, 78),
(3020, 45, 82),
(3021, 45, 105),
(3022, 45, 113),
(3023, 45, 219),
(3024, 45, 73),
(3025, 45, 80),
(3026, 45, 85),
(3027, 45, 106),
(3028, 45, 123),
(3029, 45, 187),
(3030, 45, 11),
(3031, 45, 74),
(3032, 45, 93),
(3033, 45, 107),
(3034, 45, 188),
(3035, 45, 72),
(3036, 45, 89),
(3037, 45, 189),
(3038, 45, 92),
(3039, 45, 175),
(3040, 48, 176),
(3041, 48, 78),
(3042, 48, 82),
(3043, 48, 105),
(3044, 48, 113),
(3045, 48, 219),
(3046, 48, 73),
(3047, 48, 80),
(3048, 48, 85),
(3049, 48, 106),
(3050, 48, 123),
(3051, 48, 187),
(3052, 48, 11),
(3053, 48, 74),
(3054, 48, 93),
(3055, 48, 107),
(3056, 48, 188),
(3057, 48, 72),
(3058, 48, 89),
(3059, 48, 189),
(3060, 48, 92),
(3061, 48, 175),
(3596, 53, 176),
(3597, 53, 78),
(3598, 53, 82),
(3599, 53, 105),
(3600, 53, 113),
(3601, 53, 219),
(3602, 53, 73),
(3603, 53, 80),
(3604, 53, 85),
(3605, 53, 106),
(3606, 53, 123),
(3607, 53, 187),
(3608, 53, 11),
(3609, 53, 74),
(3610, 53, 93),
(3611, 53, 107),
(3612, 53, 188),
(3613, 53, 72),
(3614, 53, 89),
(3615, 53, 189),
(3616, 53, 84),
(3617, 53, 92),
(3618, 53, 175),
(3619, 54, 176),
(3620, 54, 78),
(3621, 54, 82),
(3622, 54, 105),
(3623, 54, 113),
(3624, 54, 219),
(3625, 54, 73),
(3626, 54, 80),
(3627, 54, 85),
(3628, 54, 106),
(3629, 54, 123),
(3630, 54, 187),
(3631, 54, 11),
(3632, 54, 74),
(3633, 54, 93),
(3634, 54, 107),
(3635, 54, 188),
(3636, 54, 72),
(3637, 54, 89),
(3638, 54, 189),
(3639, 54, 84),
(3640, 54, 92),
(3641, 54, 175),
(3642, 55, 176),
(3643, 55, 78),
(3644, 55, 82),
(3645, 55, 105),
(3646, 55, 113),
(3647, 55, 219),
(3648, 55, 73),
(3649, 55, 80),
(3650, 55, 85),
(3651, 55, 106),
(3652, 55, 123),
(3653, 55, 187),
(3654, 55, 11),
(3655, 55, 74),
(3656, 55, 93),
(3657, 55, 107),
(3658, 55, 188),
(3659, 55, 72),
(3660, 55, 89),
(3661, 55, 189),
(3662, 55, 84),
(3663, 55, 92),
(3664, 55, 175),
(3665, 56, 75),
(3666, 56, 176),
(3667, 56, 6),
(3668, 56, 71),
(3669, 56, 78),
(3670, 56, 82),
(3671, 56, 105),
(3672, 56, 113),
(3673, 56, 219),
(3674, 56, 73),
(3675, 56, 76),
(3676, 56, 80),
(3677, 56, 85),
(3678, 56, 106),
(3679, 56, 123),
(3680, 56, 187),
(3681, 56, 11),
(3682, 56, 74),
(3683, 56, 77),
(3684, 56, 93),
(3685, 56, 107),
(3686, 56, 188),
(3687, 56, 72),
(3688, 56, 89),
(3689, 56, 189),
(3690, 56, 84),
(3691, 56, 70),
(3692, 56, 92),
(3693, 56, 7),
(3694, 56, 175),
(3695, 57, 75),
(3696, 57, 176),
(3697, 57, 6),
(3698, 57, 71),
(3699, 57, 78),
(3700, 57, 82),
(3701, 57, 105),
(3702, 57, 113),
(3703, 57, 219),
(3704, 57, 73),
(3705, 57, 76),
(3706, 57, 80),
(3707, 57, 85),
(3708, 57, 106),
(3709, 57, 123),
(3710, 57, 187),
(3711, 57, 11),
(3712, 57, 74),
(3713, 57, 77),
(3714, 57, 93),
(3715, 57, 107),
(3716, 57, 188),
(3717, 57, 72),
(3718, 57, 89),
(3719, 57, 189),
(3720, 57, 84),
(3721, 57, 70),
(3722, 57, 92),
(3723, 57, 7),
(3724, 57, 175),
(3725, 52, 176),
(3726, 52, 78),
(3727, 52, 82),
(3728, 52, 105),
(3729, 52, 113),
(3730, 52, 219),
(3731, 52, 73),
(3732, 52, 80),
(3733, 52, 85),
(3734, 52, 106),
(3735, 52, 123),
(3736, 52, 187),
(3737, 52, 11),
(3738, 52, 74),
(3739, 52, 93),
(3740, 52, 107),
(3741, 52, 188),
(3742, 52, 72),
(3743, 52, 89),
(3744, 52, 189),
(3745, 52, 92),
(3746, 52, 175),
(3769, 51, 176),
(3770, 51, 78),
(3771, 51, 82),
(3772, 51, 105),
(3773, 51, 113),
(3774, 51, 219),
(3775, 51, 73),
(3776, 51, 80),
(3777, 51, 85),
(3778, 51, 106),
(3779, 51, 123),
(3780, 51, 187),
(3781, 51, 11),
(3782, 51, 74),
(3783, 51, 93),
(3784, 51, 107),
(3785, 51, 188),
(3786, 51, 72),
(3787, 51, 89),
(3788, 51, 189),
(3789, 51, 92),
(3790, 51, 175),
(3791, 50, 176),
(3792, 50, 78),
(3793, 50, 82),
(3794, 50, 105),
(3795, 50, 113),
(3796, 50, 219),
(3797, 50, 73),
(3798, 50, 80),
(3799, 50, 85),
(3800, 50, 106),
(3801, 50, 123),
(3802, 50, 187),
(3803, 50, 11),
(3804, 50, 74),
(3805, 50, 93),
(3806, 50, 107),
(3807, 50, 188),
(3808, 50, 72),
(3809, 50, 89),
(3810, 50, 189),
(3811, 50, 92),
(3812, 50, 175),
(3813, 49, 176),
(3814, 49, 78),
(3815, 49, 82),
(3816, 49, 105),
(3817, 49, 113),
(3818, 49, 219),
(3819, 49, 73),
(3820, 49, 80),
(3821, 49, 85),
(3822, 49, 106),
(3823, 49, 123),
(3824, 49, 187),
(3825, 49, 11),
(3826, 49, 74),
(3827, 49, 93),
(3828, 49, 107),
(3829, 49, 188),
(3830, 49, 72),
(3831, 49, 89),
(3832, 49, 189),
(3833, 49, 92),
(3834, 49, 175),
(3835, 61, 1),
(3836, 61, 20),
(3837, 61, 75),
(3838, 61, 176),
(3839, 61, 190),
(3840, 61, 196),
(3841, 61, 200),
(3842, 61, 201),
(3843, 61, 202),
(3844, 61, 209),
(3845, 61, 220),
(3846, 61, 2),
(3847, 61, 6),
(3848, 61, 71),
(3849, 61, 78),
(3850, 61, 82),
(3851, 61, 105),
(3852, 61, 113),
(3853, 61, 144),
(3854, 61, 194),
(3855, 61, 210),
(3856, 61, 219),
(3857, 61, 5),
(3858, 61, 22),
(3859, 61, 73),
(3860, 61, 76),
(3861, 61, 80),
(3862, 61, 85),
(3863, 61, 106),
(3864, 61, 123),
(3865, 61, 187),
(3866, 61, 195),
(3867, 61, 211),
(3868, 61, 11),
(3869, 61, 23),
(3870, 61, 74),
(3871, 61, 77),
(3872, 61, 86),
(3873, 61, 93),
(3874, 61, 107),
(3875, 61, 125),
(3876, 61, 188),
(3877, 61, 19),
(3878, 61, 21),
(3879, 61, 72),
(3880, 61, 83),
(3881, 61, 89),
(3882, 61, 118),
(3883, 61, 189),
(3884, 61, 14),
(3885, 61, 84),
(3886, 61, 119),
(3887, 61, 126),
(3888, 61, 192),
(3889, 61, 15),
(3890, 61, 70),
(3891, 61, 92),
(3892, 61, 120),
(3893, 61, 191),
(3894, 61, 7),
(3895, 61, 51),
(3896, 61, 111),
(3897, 61, 121),
(3898, 61, 175),
(3899, 61, 8),
(3900, 61, 17),
(3901, 61, 122),
(3902, 61, 143),
(3903, 61, 18),
(3904, 61, 124),
(3905, 61, 142),
(3906, 61, 171),
(3907, 61, 90),
(3908, 61, 108),
(3909, 61, 141),
(3910, 61, 147),
(3911, 61, 96),
(3912, 61, 109),
(3913, 61, 148),
(3914, 61, 97),
(3915, 61, 110),
(3916, 61, 52),
(3917, 61, 98),
(3918, 61, 25),
(3919, 61, 129),
(3920, 61, 31),
(3921, 61, 91),
(3922, 61, 32),
(3923, 61, 127),
(3924, 61, 33),
(3925, 61, 128),
(3926, 61, 172),
(3927, 61, 173),
(3928, 61, 174),
(3929, 61, 60),
(3930, 61, 65),
(3931, 61, 66),
(3932, 61, 63),
(3933, 61, 64),
(3934, 61, 12),
(3935, 61, 61),
(3936, 61, 62),
(3937, 61, 114),
(3938, 61, 134),
(3939, 61, 136),
(3940, 61, 137),
(3941, 61, 139),
(3942, 61, 138),
(3943, 61, 140),
(3944, 61, 150),
(3945, 61, 165),
(3946, 61, 193),
(3947, 60, 1),
(3948, 60, 20),
(3949, 60, 75),
(3950, 60, 87),
(3951, 60, 176),
(3952, 60, 190),
(3953, 60, 196),
(3954, 60, 200),
(3955, 60, 202),
(3956, 60, 209),
(3957, 60, 2),
(3958, 60, 6),
(3959, 60, 9),
(3960, 60, 71),
(3961, 60, 78),
(3962, 60, 82),
(3963, 60, 105),
(3964, 60, 113),
(3965, 60, 144),
(3966, 60, 194),
(3967, 60, 210),
(3968, 60, 219),
(3969, 60, 5),
(3970, 60, 10),
(3971, 60, 22),
(3972, 60, 73),
(3973, 60, 76),
(3974, 60, 80),
(3975, 60, 85),
(3976, 60, 106),
(3977, 60, 123),
(3978, 60, 187),
(3979, 60, 195),
(3980, 60, 211),
(3981, 60, 11),
(3982, 60, 23),
(3983, 60, 74),
(3984, 60, 77),
(3985, 60, 86),
(3986, 60, 93),
(3987, 60, 107),
(3988, 60, 125),
(3989, 60, 135),
(3990, 60, 188),
(3991, 60, 19),
(3992, 60, 21),
(3993, 60, 72),
(3994, 60, 83),
(3995, 60, 88),
(3996, 60, 89),
(3997, 60, 118),
(3998, 60, 189),
(3999, 60, 14),
(4000, 60, 84),
(4001, 60, 119),
(4002, 60, 192),
(4003, 60, 15),
(4004, 60, 70),
(4005, 60, 92),
(4006, 60, 120),
(4007, 60, 191),
(4008, 60, 7),
(4009, 60, 51),
(4010, 60, 111),
(4011, 60, 121),
(4012, 60, 175),
(4013, 60, 8),
(4014, 60, 17),
(4015, 60, 122),
(4016, 60, 143),
(4017, 60, 18),
(4018, 60, 124),
(4019, 60, 142),
(4020, 60, 171),
(4021, 60, 90),
(4022, 60, 108),
(4023, 60, 141),
(4024, 60, 147),
(4025, 60, 96),
(4026, 60, 109),
(4027, 60, 148),
(4028, 60, 97),
(4029, 60, 110),
(4030, 60, 52),
(4031, 60, 98),
(4032, 60, 25),
(4033, 60, 129),
(4034, 60, 31),
(4035, 60, 91),
(4036, 60, 32),
(4037, 60, 127),
(4038, 60, 33),
(4039, 60, 128),
(4040, 60, 172),
(4041, 60, 173),
(4042, 60, 174),
(4043, 60, 60),
(4044, 60, 65),
(4045, 60, 66),
(4046, 60, 63),
(4047, 60, 64),
(4048, 60, 12),
(4049, 60, 61),
(4050, 60, 62),
(4051, 60, 114),
(4052, 60, 134),
(4053, 60, 136),
(4054, 60, 137),
(4055, 60, 139),
(4056, 60, 138),
(4057, 60, 140),
(4058, 60, 150),
(4059, 60, 165),
(4060, 60, 193),
(4061, 59, 75),
(4062, 59, 176),
(4063, 59, 6),
(4064, 59, 71),
(4065, 59, 78),
(4066, 59, 82),
(4067, 59, 105),
(4068, 59, 113),
(4069, 59, 219),
(4070, 59, 73),
(4071, 59, 76),
(4072, 59, 80),
(4073, 59, 85),
(4074, 59, 106),
(4075, 59, 123),
(4076, 59, 187),
(4077, 59, 11),
(4078, 59, 74),
(4079, 59, 77),
(4080, 59, 93),
(4081, 59, 107),
(4082, 59, 188),
(4083, 59, 72),
(4084, 59, 89),
(4085, 59, 189),
(4086, 59, 84),
(4087, 59, 70),
(4088, 59, 92),
(4089, 59, 7),
(4090, 59, 175),
(4091, 58, 75),
(4092, 58, 176),
(4093, 58, 6),
(4094, 58, 71),
(4095, 58, 78),
(4096, 58, 82),
(4097, 58, 105),
(4098, 58, 113),
(4099, 58, 219),
(4100, 58, 73),
(4101, 58, 76),
(4102, 58, 80),
(4103, 58, 85),
(4104, 58, 106),
(4105, 58, 123),
(4106, 58, 187),
(4107, 58, 11),
(4108, 58, 74),
(4109, 58, 77),
(4110, 58, 93),
(4111, 58, 107),
(4112, 58, 188),
(4113, 58, 72),
(4114, 58, 89),
(4115, 58, 189),
(4116, 58, 84),
(4117, 58, 70),
(4118, 58, 92),
(4119, 58, 7),
(4120, 58, 175);

-- --------------------------------------------------------

--
-- Table structure for table `social`
--

DROP TABLE IF EXISTS `social`;
CREATE TABLE `social` (
  `social_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `icon` text COLLATE utf8_unicode_ci NOT NULL,
  `iconwidth` int(11) NOT NULL,
  `iconheight` int(11) NOT NULL,
  `url` text COLLATE utf8_unicode_ci NOT NULL,
  `tooltip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ordernum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `social`
--

INSERT INTO `social` (`social_id`, `name`, `icon`, `iconwidth`, `iconheight`, `url`, `tooltip`, `ordernum`) VALUES
(1, 'Facebook', 'images/socialmedia/facebook.png', 24, 24, '', 'Entire entire Facebook URL.', 4),
(2, 'Twitter', 'images/socialmedia/twitter.png', 24, 24, 'http://www.twitter.com/', 'Enter your Twitter username.', 3),
(3, 'Youtube', 'images/socialmedia/youtube.png', 24, 24, 'http://youtube.com/', 'Enter your Youtube username.', 2),
(4, 'Google Plus', 'images/socialmedia/googleplus.png', 24, 24, '', 'Enter entire Google Plus URL.', 1),
(19, 'Twitch', 'plugins/twitch/images/twitch.png', 24, 24, 'http://twitch.tv/', 'Enter your Twitch username', 5);

-- --------------------------------------------------------

--
-- Table structure for table `social_members`
--

DROP TABLE IF EXISTS `social_members`;
CREATE TABLE `social_members` (
  `socialmember_id` int(11) NOT NULL,
  `social_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `social_members`
--

INSERT INTO `social_members` (`socialmember_id`, `social_id`, `member_id`, `value`) VALUES
(1, 19, 4, ''),
(2, 1, 4, ''),
(3, 2, 4, ''),
(4, 3, 4, 'https://www.youtube.com/channel/UCPsHKX7R30CHqLFPerj1mkg'),
(5, 4, 4, ''),
(6, 19, 8, ''),
(7, 1, 8, ''),
(8, 2, 8, ''),
(9, 3, 8, ''),
(10, 4, 8, '');

-- --------------------------------------------------------

--
-- Table structure for table `squadapps`
--

DROP TABLE IF EXISTS `squadapps`;
CREATE TABLE `squadapps` (
  `squadapp_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `squad_id` int(11) NOT NULL,
  `message` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `applydate` int(11) NOT NULL,
  `dateaction` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `squadmember_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `squadinvites`
--

DROP TABLE IF EXISTS `squadinvites`;
CREATE TABLE `squadinvites` (
  `squadinvite_id` int(11) NOT NULL,
  `squad_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `datesent` int(11) NOT NULL,
  `dateaction` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `message` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `startingrank_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `squadnews`
--

DROP TABLE IF EXISTS `squadnews`;
CREATE TABLE `squadnews` (
  `squadnews_id` int(11) NOT NULL,
  `squad_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `newstype` int(11) NOT NULL,
  `dateposted` int(11) NOT NULL,
  `postsubject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `newspost` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `lasteditmember_id` int(11) NOT NULL,
  `lasteditdate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `squadranks`
--

DROP TABLE IF EXISTS `squadranks`;
CREATE TABLE `squadranks` (
  `squadrank_id` int(11) NOT NULL,
  `squad_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortnum` int(11) NOT NULL,
  `postnews` int(11) NOT NULL,
  `managenews` int(11) NOT NULL,
  `postshoutbox` int(11) NOT NULL,
  `manageshoutbox` int(11) NOT NULL,
  `addrank` int(11) NOT NULL,
  `manageranks` int(11) NOT NULL,
  `editprofile` int(11) NOT NULL,
  `sendinvites` int(11) NOT NULL,
  `acceptapps` int(11) NOT NULL,
  `setrank` int(11) NOT NULL,
  `removemember` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `squads`
--

DROP TABLE IF EXISTS `squads`;
CREATE TABLE `squads` (
  `squad_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `logourl` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `recruitingstatus` int(11) NOT NULL,
  `datecreated` int(11) NOT NULL,
  `privateshoutbox` int(11) NOT NULL,
  `website` mediumtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `squads_members`
--

DROP TABLE IF EXISTS `squads_members`;
CREATE TABLE `squads_members` (
  `squadmember_id` int(11) NOT NULL,
  `squad_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `squadrank_id` int(11) NOT NULL,
  `datejoined` int(11) NOT NULL,
  `lastpromotion` int(11) NOT NULL,
  `lastdemotion` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tableupdates`
--

DROP TABLE IF EXISTS `tableupdates`;
CREATE TABLE `tableupdates` (
  `tableupdate_id` int(11) NOT NULL,
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `updatetime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tableupdates`
--

INSERT INTO `tableupdates` (`tableupdate_id`, `tablename`, `updatetime`) VALUES
(1, 'websiteinfo', 1477695003),
(2, 'hitcounter', 1477696278),
(3, 'app_captcha', 1477686417),
(4, 'memberapps', 1477686458),
(5, 'notifications', 1477686458),
(6, 'members', 1477686458),
(7, 'gamesplayed', 1477527169),
(8, 'news', 1477685034),
(9, 'menuitem_link', 1477689562),
(10, 'menu_item', 1477689562),
(11, 'poll_votes', 1477690938),
(12, 'profileoptions_values', 1477685670),
(13, 'social_members', 1477685670),
(14, 'gamesplayed_members', 1477685670),
(15, 'ranks', 1477691237),
(16, 'rank_privileges', 1477691238),
(17, 'forum_category', 1477682010),
(18, 'forum_board', 1477682071),
(19, 'logs', 1477683197),
(20, 'rankcategory', 1477684360),
(21, 'failban', 1477686305),
(22, 'menuitem_custompage', 1477689418),
(23, 'menu_category', 1477691488),
(24, 'custompages', 1477689505);

-- --------------------------------------------------------

--
-- Table structure for table `tournamentmatch`
--

DROP TABLE IF EXISTS `tournamentmatch`;
CREATE TABLE `tournamentmatch` (
  `tournamentmatch_id` int(11) NOT NULL,
  `tournament_id` int(11) NOT NULL,
  `round` int(11) NOT NULL,
  `team1_id` int(11) NOT NULL,
  `team2_id` int(11) NOT NULL,
  `team1score` int(11) NOT NULL,
  `team2score` int(11) NOT NULL,
  `outcome` int(11) NOT NULL,
  `replayteam1url` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `replayteam2url` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `adminreplayurl` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `team1approve` int(11) NOT NULL,
  `team2approve` int(11) NOT NULL,
  `nextmatch_id` int(11) NOT NULL,
  `sortnum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tournamentplayers`
--

DROP TABLE IF EXISTS `tournamentplayers`;
CREATE TABLE `tournamentplayers` (
  `tournamentplayer_id` int(11) NOT NULL,
  `tournament_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `displayname` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tournamentpools`
--

DROP TABLE IF EXISTS `tournamentpools`;
CREATE TABLE `tournamentpools` (
  `tournamentpool_id` int(11) NOT NULL,
  `tournament_id` int(11) NOT NULL,
  `finished` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tournamentpools_teams`
--

DROP TABLE IF EXISTS `tournamentpools_teams`;
CREATE TABLE `tournamentpools_teams` (
  `poolteam_id` int(11) NOT NULL,
  `tournament_id` int(11) NOT NULL,
  `pool_id` int(11) NOT NULL,
  `team1_id` int(11) NOT NULL,
  `team2_id` int(11) NOT NULL,
  `team1score` int(11) NOT NULL,
  `team2score` int(11) NOT NULL,
  `team1approve` int(1) NOT NULL,
  `team2approve` int(1) NOT NULL,
  `replayteam1url` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `replayteam2url` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `winner` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tournaments`
--

DROP TABLE IF EXISTS `tournaments`;
CREATE TABLE `tournaments` (
  `tournament_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `gamesplayed_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `seedtype` int(11) NOT NULL,
  `startdate` int(11) NOT NULL,
  `timezone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `eliminations` int(11) NOT NULL,
  `playersperteam` int(11) NOT NULL,
  `maxteams` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `requirereplay` int(10) NOT NULL,
  `access` int(11) NOT NULL,
  `imageurl` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tournamentteams`
--

DROP TABLE IF EXISTS `tournamentteams`;
CREATE TABLE `tournamentteams` (
  `tournamentteam_id` int(11) NOT NULL,
  `tournament_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `seed` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tournament_managers`
--

DROP TABLE IF EXISTS `tournament_managers`;
CREATE TABLE `tournament_managers` (
  `tournamentmanager_id` int(11) NOT NULL,
  `tournament_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tournament_reminder`
--

DROP TABLE IF EXISTS `tournament_reminder`;
CREATE TABLE `tournament_reminder` (
  `tournamentreminder_id` int(11) NOT NULL,
  `emailnotificationqueue_id` int(11) NOT NULL,
  `tournament_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `websiteinfo`
--

DROP TABLE IF EXISTS `websiteinfo`;
CREATE TABLE `websiteinfo` (
  `websiteinfo_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `websiteinfo`
--

INSERT INTO `websiteinfo` (`websiteinfo_id`, `name`, `value`) VALUES
(1, 'clanname', '9th Special Forces Group'),
(2, 'clantag', '[9SFG]'),
(3, 'preventhack', '5555'),
(4, 'maxdsl', '0'),
(5, 'theme', 'ribboncamo'),
(6, 'lowdsl', '#00FF00'),
(7, 'meddsl', '#FFFF52'),
(8, 'highdsl', '#F75B5B'),
(9, 'logourl', 'images/logo.png'),
(10, 'forumurl', 'http://localhost/cs4git/forum'),
(11, 'failedlogins', '8'),
(12, 'maxdiplomacy', '10'),
(13, 'mostonline', '4'),
(14, 'mostonlinedate', '1477685646'),
(15, 'memberregistration', '0'),
(16, 'memberapproval', '0'),
(17, 'medalorder', '1'),
(18, 'newsticker', 'Welcome to the Site!'),
(19, 'newstickercolor', '#000000'),
(20, 'newstickersize', '14'),
(21, 'newstickerbold', ''),
(22, 'newstickeritalic', ''),
(23, 'debugmode', '0'),
(24, 'privateforum', '0'),
(25, 'privateprofile', '0'),
(26, 'updatemenu', '1399187245'),
(27, 'hpimagetype', 'slider'),
(28, 'hpimagewidth', '600'),
(29, 'hpimageheight', '400'),
(30, 'hpimagewidthunit', 'px'),
(31, 'hpimageheightunit', 'px'),
(32, 'forum_showmedal', '1'),
(33, 'forum_medalcount', '5'),
(34, 'forum_medalwidth', '50'),
(35, 'forum_medalheight', '13'),
(36, 'forum_medalwidthunit', 'px'),
(37, 'forum_medalheightunit', 'px'),
(38, 'forum_showrank', '1'),
(39, 'forum_rankwidth', '50'),
(40, 'forum_rankheight', '75'),
(41, 'forum_rankwidthunit', 'px'),
(42, 'forum_rankheightunit', 'px'),
(43, 'forum_postsperpage', '0'),
(44, 'forum_topicsperpage', '0'),
(45, 'forum_imagewidth', '500'),
(46, 'forum_imageheight', '500'),
(47, 'forum_sigwidth', '500'),
(48, 'forum_sigheight', '150'),
(49, 'forum_imagewidthunit', 'px'),
(50, 'forum_imageheightunit', 'px'),
(51, 'forum_sigwidthunit', 'px'),
(52, 'forum_sigheightunit', 'px'),
(53, 'forum_linkimages', '1'),
(54, 'forum_hidesignatures', ''),
(55, 'forum_avatarwidth', '50'),
(56, 'forum_avatarheight', '50'),
(57, 'forum_avatarwidthunit', 'px'),
(58, 'forum_avatarheightunit', 'px'),
(59, 'hideinactive', '0'),
(60, 'hpnews', '0'),
(61, 'sortnum', '0'),
(62, 'news_postsperpage', '10'),
(63, 'default_timezone', 'America/Los_Angeles'),
(64, 'date_format', 'l, F j, Y'),
(65, 'display_date', '1'),
(66, 'emailqueue_lastsent', '1477695003'),
(67, 'forum_newindicator', '5'),
(68, 'emailqueue_delay', '30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_captcha`
--
ALTER TABLE `app_captcha`
  ADD PRIMARY KEY (`appcaptcha_id`);

--
-- Indexes for table `app_components`
--
ALTER TABLE `app_components`
  ADD PRIMARY KEY (`appcomponent_id`);

--
-- Indexes for table `app_selectvalues`
--
ALTER TABLE `app_selectvalues`
  ADD PRIMARY KEY (`appselectvalue_id`);

--
-- Indexes for table `app_values`
--
ALTER TABLE `app_values`
  ADD PRIMARY KEY (`appvalue_id`);

--
-- Indexes for table `clocks`
--
ALTER TABLE `clocks`
  ADD PRIMARY KEY (`clock_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `console`
--
ALTER TABLE `console`
  ADD PRIMARY KEY (`console_id`);

--
-- Indexes for table `consolecategory`
--
ALTER TABLE `consolecategory`
  ADD PRIMARY KEY (`consolecategory_id`);

--
-- Indexes for table `console_members`
--
ALTER TABLE `console_members`
  ADD PRIMARY KEY (`privilege_id`);

--
-- Indexes for table `customform`
--
ALTER TABLE `customform`
  ADD PRIMARY KEY (`customform_id`);

--
-- Indexes for table `customform_components`
--
ALTER TABLE `customform_components`
  ADD PRIMARY KEY (`component_id`);

--
-- Indexes for table `customform_selectvalues`
--
ALTER TABLE `customform_selectvalues`
  ADD PRIMARY KEY (`selectvalue_id`);

--
-- Indexes for table `customform_submission`
--
ALTER TABLE `customform_submission`
  ADD PRIMARY KEY (`submission_id`);

--
-- Indexes for table `customform_values`
--
ALTER TABLE `customform_values`
  ADD PRIMARY KEY (`value_id`);

--
-- Indexes for table `custompages`
--
ALTER TABLE `custompages`
  ADD PRIMARY KEY (`custompage_id`);

--
-- Indexes for table `diplomacy`
--
ALTER TABLE `diplomacy`
  ADD PRIMARY KEY (`diplomacy_id`);

--
-- Indexes for table `diplomacy_request`
--
ALTER TABLE `diplomacy_request`
  ADD PRIMARY KEY (`diplomacyrequest_id`);

--
-- Indexes for table `diplomacy_status`
--
ALTER TABLE `diplomacy_status`
  ADD PRIMARY KEY (`diplomacystatus_id`);

--
-- Indexes for table `downloadcategory`
--
ALTER TABLE `downloadcategory`
  ADD PRIMARY KEY (`downloadcategory_id`);

--
-- Indexes for table `downloads`
--
ALTER TABLE `downloads`
  ADD PRIMARY KEY (`download_id`);

--
-- Indexes for table `download_extensions`
--
ALTER TABLE `download_extensions`
  ADD PRIMARY KEY (`extension_id`);

--
-- Indexes for table `emailnotifications_queue`
--
ALTER TABLE `emailnotifications_queue`
  ADD PRIMARY KEY (`emailnotificationsqueue_id`);

--
-- Indexes for table `emailnotifications_settings`
--
ALTER TABLE `emailnotifications_settings`
  ADD PRIMARY KEY (`emailnotificationsetting_id`),
  ADD UNIQUE KEY `member_id` (`member_id`);

--
-- Indexes for table `eventchat`
--
ALTER TABLE `eventchat`
  ADD PRIMARY KEY (`eventchat_id`);

--
-- Indexes for table `eventchat_messages`
--
ALTER TABLE `eventchat_messages`
  ADD PRIMARY KEY (`eventchatmessage_id`);

--
-- Indexes for table `eventchat_roomlist`
--
ALTER TABLE `eventchat_roomlist`
  ADD PRIMARY KEY (`eventchatlist_id`);

--
-- Indexes for table `eventmessages`
--
ALTER TABLE `eventmessages`
  ADD PRIMARY KEY (`eventmessage_id`);

--
-- Indexes for table `eventmessage_comment`
--
ALTER TABLE `eventmessage_comment`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `eventpositions`
--
ALTER TABLE `eventpositions`
  ADD PRIMARY KEY (`position_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `events_members`
--
ALTER TABLE `events_members`
  ADD PRIMARY KEY (`eventmember_id`);

--
-- Indexes for table `event_reminder`
--
ALTER TABLE `event_reminder`
  ADD PRIMARY KEY (`eventreminder_id`);

--
-- Indexes for table `failban`
--
ALTER TABLE `failban`
  ADD PRIMARY KEY (`failban_id`);

--
-- Indexes for table `forgotpass`
--
ALTER TABLE `forgotpass`
  ADD PRIMARY KEY (`rqid`);

--
-- Indexes for table `forum_attachments`
--
ALTER TABLE `forum_attachments`
  ADD PRIMARY KEY (`forumattachment_id`);

--
-- Indexes for table `forum_board`
--
ALTER TABLE `forum_board`
  ADD PRIMARY KEY (`forumboard_id`);

--
-- Indexes for table `forum_category`
--
ALTER TABLE `forum_category`
  ADD PRIMARY KEY (`forumcategory_id`);

--
-- Indexes for table `forum_memberaccess`
--
ALTER TABLE `forum_memberaccess`
  ADD PRIMARY KEY (`forummemberaccess_id`);

--
-- Indexes for table `forum_moderator`
--
ALTER TABLE `forum_moderator`
  ADD PRIMARY KEY (`forummoderator_id`);

--
-- Indexes for table `forum_post`
--
ALTER TABLE `forum_post`
  ADD PRIMARY KEY (`forumpost_id`);

--
-- Indexes for table `forum_rankaccess`
--
ALTER TABLE `forum_rankaccess`
  ADD PRIMARY KEY (`forumrankaccess_id`);

--
-- Indexes for table `forum_topic`
--
ALTER TABLE `forum_topic`
  ADD PRIMARY KEY (`forumtopic_id`);

--
-- Indexes for table `forum_topicseen`
--
ALTER TABLE `forum_topicseen`
  ADD PRIMARY KEY (`forumtopicseen_id`);

--
-- Indexes for table `freezemedals_members`
--
ALTER TABLE `freezemedals_members`
  ADD PRIMARY KEY (`freezemedal_id`);

--
-- Indexes for table `gamesplayed`
--
ALTER TABLE `gamesplayed`
  ADD PRIMARY KEY (`gamesplayed_id`);

--
-- Indexes for table `gamesplayed_members`
--
ALTER TABLE `gamesplayed_members`
  ADD PRIMARY KEY (`gamemember_id`);

--
-- Indexes for table `gamestats`
--
ALTER TABLE `gamestats`
  ADD PRIMARY KEY (`gamestats_id`);

--
-- Indexes for table `gamestats_members`
--
ALTER TABLE `gamestats_members`
  ADD PRIMARY KEY (`gamestatmember_id`);

--
-- Indexes for table `hitcounter`
--
ALTER TABLE `hitcounter`
  ADD PRIMARY KEY (`hit_id`);

--
-- Indexes for table `iarequest`
--
ALTER TABLE `iarequest`
  ADD PRIMARY KEY (`iarequest_id`);

--
-- Indexes for table `iarequest_messages`
--
ALTER TABLE `iarequest_messages`
  ADD PRIMARY KEY (`iamessage_id`);

--
-- Indexes for table `imageslider`
--
ALTER TABLE `imageslider`
  ADD PRIMARY KEY (`imageslider_id`);

--
-- Indexes for table `ipban`
--
ALTER TABLE `ipban`
  ADD PRIMARY KEY (`ipban_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `medals`
--
ALTER TABLE `medals`
  ADD PRIMARY KEY (`medal_id`);

--
-- Indexes for table `medals_members`
--
ALTER TABLE `medals_members`
  ADD PRIMARY KEY (`medalmember_id`);

--
-- Indexes for table `memberapps`
--
ALTER TABLE `memberapps`
  ADD PRIMARY KEY (`memberapp_id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`member_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `membersonlypage`
--
ALTER TABLE `membersonlypage`
  ADD PRIMARY KEY (`page_id`);

--
-- Indexes for table `menuitem_customblock`
--
ALTER TABLE `menuitem_customblock`
  ADD PRIMARY KEY (`menucustomblock_id`);

--
-- Indexes for table `menuitem_custompage`
--
ALTER TABLE `menuitem_custompage`
  ADD PRIMARY KEY (`menucustompage_id`);

--
-- Indexes for table `menuitem_image`
--
ALTER TABLE `menuitem_image`
  ADD PRIMARY KEY (`menuimage_id`);

--
-- Indexes for table `menuitem_link`
--
ALTER TABLE `menuitem_link`
  ADD PRIMARY KEY (`menulink_id`);

--
-- Indexes for table `menuitem_shoutbox`
--
ALTER TABLE `menuitem_shoutbox`
  ADD PRIMARY KEY (`menushoutbox_id`);

--
-- Indexes for table `menu_category`
--
ALTER TABLE `menu_category`
  ADD PRIMARY KEY (`menucategory_id`);

--
-- Indexes for table `menu_item`
--
ALTER TABLE `menu_item`
  ADD PRIMARY KEY (`menuitem_id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`news_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `plugins`
--
ALTER TABLE `plugins`
  ADD PRIMARY KEY (`plugin_id`);

--
-- Indexes for table `plugin_config`
--
ALTER TABLE `plugin_config`
  ADD PRIMARY KEY (`pluginconfig_id`);

--
-- Indexes for table `plugin_pages`
--
ALTER TABLE `plugin_pages`
  ADD PRIMARY KEY (`pluginpage_id`);

--
-- Indexes for table `polls`
--
ALTER TABLE `polls`
  ADD PRIMARY KEY (`poll_id`);

--
-- Indexes for table `poll_memberaccess`
--
ALTER TABLE `poll_memberaccess`
  ADD PRIMARY KEY (`pollmemberaccess_id`);

--
-- Indexes for table `poll_options`
--
ALTER TABLE `poll_options`
  ADD PRIMARY KEY (`polloption_id`);

--
-- Indexes for table `poll_rankaccess`
--
ALTER TABLE `poll_rankaccess`
  ADD PRIMARY KEY (`pollrankaccess_id`);

--
-- Indexes for table `poll_votes`
--
ALTER TABLE `poll_votes`
  ADD PRIMARY KEY (`pollvote_id`);

--
-- Indexes for table `privatemessages`
--
ALTER TABLE `privatemessages`
  ADD PRIMARY KEY (`pm_id`);

--
-- Indexes for table `privatemessage_folders`
--
ALTER TABLE `privatemessage_folders`
  ADD PRIMARY KEY (`pmfolder_id`);

--
-- Indexes for table `privatemessage_members`
--
ALTER TABLE `privatemessage_members`
  ADD PRIMARY KEY (`pmmember_id`);

--
-- Indexes for table `profilecategory`
--
ALTER TABLE `profilecategory`
  ADD PRIMARY KEY (`profilecategory_id`);

--
-- Indexes for table `profileoptions`
--
ALTER TABLE `profileoptions`
  ADD PRIMARY KEY (`profileoption_id`);

--
-- Indexes for table `profileoptions_select`
--
ALTER TABLE `profileoptions_select`
  ADD PRIMARY KEY (`selectopt_id`);

--
-- Indexes for table `profileoptions_values`
--
ALTER TABLE `profileoptions_values`
  ADD PRIMARY KEY (`values_id`);

--
-- Indexes for table `rankcategory`
--
ALTER TABLE `rankcategory`
  ADD PRIMARY KEY (`rankcategory_id`);

--
-- Indexes for table `ranks`
--
ALTER TABLE `ranks`
  ADD PRIMARY KEY (`rank_id`);

--
-- Indexes for table `rank_privileges`
--
ALTER TABLE `rank_privileges`
  ADD PRIMARY KEY (`privilege_id`);

--
-- Indexes for table `social`
--
ALTER TABLE `social`
  ADD PRIMARY KEY (`social_id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `social_members`
--
ALTER TABLE `social_members`
  ADD PRIMARY KEY (`socialmember_id`);

--
-- Indexes for table `squadapps`
--
ALTER TABLE `squadapps`
  ADD PRIMARY KEY (`squadapp_id`);

--
-- Indexes for table `squadinvites`
--
ALTER TABLE `squadinvites`
  ADD PRIMARY KEY (`squadinvite_id`);

--
-- Indexes for table `squadnews`
--
ALTER TABLE `squadnews`
  ADD PRIMARY KEY (`squadnews_id`);

--
-- Indexes for table `squadranks`
--
ALTER TABLE `squadranks`
  ADD PRIMARY KEY (`squadrank_id`);

--
-- Indexes for table `squads`
--
ALTER TABLE `squads`
  ADD PRIMARY KEY (`squad_id`);

--
-- Indexes for table `squads_members`
--
ALTER TABLE `squads_members`
  ADD PRIMARY KEY (`squadmember_id`);

--
-- Indexes for table `tableupdates`
--
ALTER TABLE `tableupdates`
  ADD PRIMARY KEY (`tableupdate_id`);

--
-- Indexes for table `tournamentmatch`
--
ALTER TABLE `tournamentmatch`
  ADD PRIMARY KEY (`tournamentmatch_id`);

--
-- Indexes for table `tournamentplayers`
--
ALTER TABLE `tournamentplayers`
  ADD PRIMARY KEY (`tournamentplayer_id`);

--
-- Indexes for table `tournamentpools`
--
ALTER TABLE `tournamentpools`
  ADD PRIMARY KEY (`tournamentpool_id`);

--
-- Indexes for table `tournamentpools_teams`
--
ALTER TABLE `tournamentpools_teams`
  ADD PRIMARY KEY (`poolteam_id`);

--
-- Indexes for table `tournaments`
--
ALTER TABLE `tournaments`
  ADD PRIMARY KEY (`tournament_id`);

--
-- Indexes for table `tournamentteams`
--
ALTER TABLE `tournamentteams`
  ADD PRIMARY KEY (`tournamentteam_id`);

--
-- Indexes for table `tournament_managers`
--
ALTER TABLE `tournament_managers`
  ADD PRIMARY KEY (`tournamentmanager_id`);

--
-- Indexes for table `tournament_reminder`
--
ALTER TABLE `tournament_reminder`
  ADD PRIMARY KEY (`tournamentreminder_id`);

--
-- Indexes for table `websiteinfo`
--
ALTER TABLE `websiteinfo`
  ADD PRIMARY KEY (`websiteinfo_id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_captcha`
--
ALTER TABLE `app_captcha`
  MODIFY `appcaptcha_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `app_components`
--
ALTER TABLE `app_components`
  MODIFY `appcomponent_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=226;
--
-- AUTO_INCREMENT for table `app_selectvalues`
--
ALTER TABLE `app_selectvalues`
  MODIFY `appselectvalue_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `app_values`
--
ALTER TABLE `app_values`
  MODIFY `appvalue_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `clocks`
--
ALTER TABLE `clocks`
  MODIFY `clock_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `console`
--
ALTER TABLE `console`
  MODIFY `console_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=221;
--
-- AUTO_INCREMENT for table `consolecategory`
--
ALTER TABLE `consolecategory`
  MODIFY `consolecategory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `console_members`
--
ALTER TABLE `console_members`
  MODIFY `privilege_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customform`
--
ALTER TABLE `customform`
  MODIFY `customform_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customform_components`
--
ALTER TABLE `customform_components`
  MODIFY `component_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customform_selectvalues`
--
ALTER TABLE `customform_selectvalues`
  MODIFY `selectvalue_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customform_submission`
--
ALTER TABLE `customform_submission`
  MODIFY `submission_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customform_values`
--
ALTER TABLE `customform_values`
  MODIFY `value_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `custompages`
--
ALTER TABLE `custompages`
  MODIFY `custompage_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `diplomacy`
--
ALTER TABLE `diplomacy`
  MODIFY `diplomacy_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `diplomacy_request`
--
ALTER TABLE `diplomacy_request`
  MODIFY `diplomacyrequest_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `diplomacy_status`
--
ALTER TABLE `diplomacy_status`
  MODIFY `diplomacystatus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `downloadcategory`
--
ALTER TABLE `downloadcategory`
  MODIFY `downloadcategory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `downloads`
--
ALTER TABLE `downloads`
  MODIFY `download_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `download_extensions`
--
ALTER TABLE `download_extensions`
  MODIFY `extension_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `emailnotifications_queue`
--
ALTER TABLE `emailnotifications_queue`
  MODIFY `emailnotificationsqueue_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `emailnotifications_settings`
--
ALTER TABLE `emailnotifications_settings`
  MODIFY `emailnotificationsetting_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `eventchat`
--
ALTER TABLE `eventchat`
  MODIFY `eventchat_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `eventchat_messages`
--
ALTER TABLE `eventchat_messages`
  MODIFY `eventchatmessage_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `eventchat_roomlist`
--
ALTER TABLE `eventchat_roomlist`
  MODIFY `eventchatlist_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `eventmessages`
--
ALTER TABLE `eventmessages`
  MODIFY `eventmessage_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `eventmessage_comment`
--
ALTER TABLE `eventmessage_comment`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `eventpositions`
--
ALTER TABLE `eventpositions`
  MODIFY `position_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `events_members`
--
ALTER TABLE `events_members`
  MODIFY `eventmember_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `event_reminder`
--
ALTER TABLE `event_reminder`
  MODIFY `eventreminder_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `failban`
--
ALTER TABLE `failban`
  MODIFY `failban_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `forgotpass`
--
ALTER TABLE `forgotpass`
  MODIFY `rqid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `forum_attachments`
--
ALTER TABLE `forum_attachments`
  MODIFY `forumattachment_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `forum_board`
--
ALTER TABLE `forum_board`
  MODIFY `forumboard_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `forum_category`
--
ALTER TABLE `forum_category`
  MODIFY `forumcategory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `forum_memberaccess`
--
ALTER TABLE `forum_memberaccess`
  MODIFY `forummemberaccess_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `forum_moderator`
--
ALTER TABLE `forum_moderator`
  MODIFY `forummoderator_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `forum_post`
--
ALTER TABLE `forum_post`
  MODIFY `forumpost_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `forum_rankaccess`
--
ALTER TABLE `forum_rankaccess`
  MODIFY `forumrankaccess_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `forum_topic`
--
ALTER TABLE `forum_topic`
  MODIFY `forumtopic_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `forum_topicseen`
--
ALTER TABLE `forum_topicseen`
  MODIFY `forumtopicseen_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `freezemedals_members`
--
ALTER TABLE `freezemedals_members`
  MODIFY `freezemedal_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gamesplayed`
--
ALTER TABLE `gamesplayed`
  MODIFY `gamesplayed_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `gamesplayed_members`
--
ALTER TABLE `gamesplayed_members`
  MODIFY `gamemember_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=340;
--
-- AUTO_INCREMENT for table `gamestats`
--
ALTER TABLE `gamestats`
  MODIFY `gamestats_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `gamestats_members`
--
ALTER TABLE `gamestats_members`
  MODIFY `gamestatmember_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `hitcounter`
--
ALTER TABLE `hitcounter`
  MODIFY `hit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
--
-- AUTO_INCREMENT for table `iarequest`
--
ALTER TABLE `iarequest`
  MODIFY `iarequest_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `iarequest_messages`
--
ALTER TABLE `iarequest_messages`
  MODIFY `iamessage_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `imageslider`
--
ALTER TABLE `imageslider`
  MODIFY `imageslider_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ipban`
--
ALTER TABLE `ipban`
  MODIFY `ipban_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `medals`
--
ALTER TABLE `medals`
  MODIFY `medal_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `medals_members`
--
ALTER TABLE `medals_members`
  MODIFY `medalmember_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `memberapps`
--
ALTER TABLE `memberapps`
  MODIFY `memberapp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `membersonlypage`
--
ALTER TABLE `membersonlypage`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `menuitem_customblock`
--
ALTER TABLE `menuitem_customblock`
  MODIFY `menucustomblock_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `menuitem_custompage`
--
ALTER TABLE `menuitem_custompage`
  MODIFY `menucustompage_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `menuitem_image`
--
ALTER TABLE `menuitem_image`
  MODIFY `menuimage_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `menuitem_link`
--
ALTER TABLE `menuitem_link`
  MODIFY `menulink_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `menuitem_shoutbox`
--
ALTER TABLE `menuitem_shoutbox`
  MODIFY `menushoutbox_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `menu_category`
--
ALTER TABLE `menu_category`
  MODIFY `menucategory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `menu_item`
--
ALTER TABLE `menu_item`
  MODIFY `menuitem_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `news_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `plugins`
--
ALTER TABLE `plugins`
  MODIFY `plugin_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `plugin_config`
--
ALTER TABLE `plugin_config`
  MODIFY `pluginconfig_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `plugin_pages`
--
ALTER TABLE `plugin_pages`
  MODIFY `pluginpage_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `polls`
--
ALTER TABLE `polls`
  MODIFY `poll_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `poll_memberaccess`
--
ALTER TABLE `poll_memberaccess`
  MODIFY `pollmemberaccess_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `poll_options`
--
ALTER TABLE `poll_options`
  MODIFY `polloption_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `poll_rankaccess`
--
ALTER TABLE `poll_rankaccess`
  MODIFY `pollrankaccess_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `poll_votes`
--
ALTER TABLE `poll_votes`
  MODIFY `pollvote_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `privatemessages`
--
ALTER TABLE `privatemessages`
  MODIFY `pm_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `privatemessage_folders`
--
ALTER TABLE `privatemessage_folders`
  MODIFY `pmfolder_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `privatemessage_members`
--
ALTER TABLE `privatemessage_members`
  MODIFY `pmmember_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `profilecategory`
--
ALTER TABLE `profilecategory`
  MODIFY `profilecategory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `profileoptions`
--
ALTER TABLE `profileoptions`
  MODIFY `profileoption_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `profileoptions_select`
--
ALTER TABLE `profileoptions_select`
  MODIFY `selectopt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `profileoptions_values`
--
ALTER TABLE `profileoptions_values`
  MODIFY `values_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `rankcategory`
--
ALTER TABLE `rankcategory`
  MODIFY `rankcategory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `ranks`
--
ALTER TABLE `ranks`
  MODIFY `rank_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT for table `rank_privileges`
--
ALTER TABLE `rank_privileges`
  MODIFY `privilege_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4121;
--
-- AUTO_INCREMENT for table `social`
--
ALTER TABLE `social`
  MODIFY `social_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `social_members`
--
ALTER TABLE `social_members`
  MODIFY `socialmember_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `squadapps`
--
ALTER TABLE `squadapps`
  MODIFY `squadapp_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `squadinvites`
--
ALTER TABLE `squadinvites`
  MODIFY `squadinvite_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `squadnews`
--
ALTER TABLE `squadnews`
  MODIFY `squadnews_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `squadranks`
--
ALTER TABLE `squadranks`
  MODIFY `squadrank_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `squads`
--
ALTER TABLE `squads`
  MODIFY `squad_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `squads_members`
--
ALTER TABLE `squads_members`
  MODIFY `squadmember_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tableupdates`
--
ALTER TABLE `tableupdates`
  MODIFY `tableupdate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `tournamentmatch`
--
ALTER TABLE `tournamentmatch`
  MODIFY `tournamentmatch_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tournamentplayers`
--
ALTER TABLE `tournamentplayers`
  MODIFY `tournamentplayer_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tournamentpools`
--
ALTER TABLE `tournamentpools`
  MODIFY `tournamentpool_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tournamentpools_teams`
--
ALTER TABLE `tournamentpools_teams`
  MODIFY `poolteam_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tournaments`
--
ALTER TABLE `tournaments`
  MODIFY `tournament_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tournamentteams`
--
ALTER TABLE `tournamentteams`
  MODIFY `tournamentteam_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tournament_managers`
--
ALTER TABLE `tournament_managers`
  MODIFY `tournamentmanager_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tournament_reminder`
--
ALTER TABLE `tournament_reminder`
  MODIFY `tournamentreminder_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `websiteinfo`
--
ALTER TABLE `websiteinfo`
  MODIFY `websiteinfo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
